#include "HandCollision.h"
#include "Config.h"
#include "ContactImpulseListener.h"
#include "MenuChecker.h"
#include "Physics.h"
#include "PlayerCharacterProxyListener.h"
#include "GrabConstraint.h"
#include "Utils.h"
#include "VRInput.h"
#include "f4vr/PlayerNodes.h"
#include <f4vr/F4VRUtils.h>
#include "WandNodeHelper.h"
#include <cstring>

// Temporarily disable the HandCollision implementation without deleting it.
#if 0

// =====================================================================
// bhkNPCollisionProxyObject - Proxy collision object structure
// Inherits from bhkNPCollisionObjectBase (NOT bhkNPCollisionObject!)
// =====================================================================
// Helper to get the target collision object from a proxy
inline RE::bhkNPCollisionObject* GetProxyTarget(RE::NiCollisionObject* proxyObj)
{
    if (!proxyObj) return nullptr;
    
    uintptr_t proxyAddr = reinterpret_cast<uintptr_t>(proxyObj);
    
    // Try offset 0x20 first
    RE::bhkNPCollisionObject** targetPtrAt20 = reinterpret_cast<RE::bhkNPCollisionObject**>(proxyAddr + 0x20);
    if (*targetPtrAt20) return *targetPtrAt20;
    
    // Try offset 0x28
    RE::bhkNPCollisionObject** targetPtrAt28 = reinterpret_cast<RE::bhkNPCollisionObject**>(proxyAddr + 0x28);
    if (*targetPtrAt28) return *targetPtrAt28;
    
    // Try offset 0x30 
    RE::bhkNPCollisionObject** targetPtrAt30 = reinterpret_cast<RE::bhkNPCollisionObject**>(proxyAddr + 0x30);
    if (*targetPtrAt30) return *targetPtrAt30;
    
    return nullptr;
}

// =========================================================================
// SEH HELPER FUNCTIONS (Must be in separate functions with no C++ objects)
// These use raw function pointers to avoid any C++ object creation
// =========================================================================

// Flag to track if SEH caught an exception (can't use C++ objects in SEH functions)
static volatile bool g_sehExceptionCaught = false;

// Helper to safely call hknpWorld::createBody
// CORRECT signature: int* hknpWorld_createBody(void* world, int* outBodyId, hknpBodyCinfo* cinfo, int additionMode, char flags)
// param_2 is an OUTPUT parameter — the bodyId is written there
// Returns bodyId on success, 0x7FFFFFFE on SEH exception
static std::uint32_t SafeCallCreateBody(void* funcPtr, void* hknpWorld, void* bodyCinfo)
{
    using Func_t = std::int32_t*(__fastcall*)(void*, std::int32_t*, void*, int, unsigned char);
    g_sehExceptionCaught = false;
    __try {
        std::int32_t outBodyId = 0x7FFFFFFF;
        ((Func_t)funcPtr)(hknpWorld, &outBodyId, bodyCinfo, 0, 0);
        return static_cast<std::uint32_t>(outBodyId);
    }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        g_sehExceptionCaught = true;
        return 0x7FFFFFFE;
    }
}

// Helper to safely read vtable from a pointer
static void* SafeReadVtable(void* ptr)
{
    __try {
        return *reinterpret_cast<void**>(ptr);
    }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        return nullptr;
    }
}

// Helper to safely call hknpBSWorld::applyHardKeyFrame for moving bodies
static bool SafeCallApplyHardKeyFrame(void* funcPtr, void* world, std::uint32_t bodyId, void* position, void* orientation, float deltaTime)
{
    using Func_t = void(__fastcall*)(void*, std::uint32_t, void*, void*, float);
    __try {
        ((Func_t)funcPtr)(world, bodyId, position, orientation, deltaTime);
        return true;
    }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// Helper to safely call hknpWorld::destroyBodies
static bool SafeCallDestroyBodies(void* funcPtr, void* hknpWorld, std::uint32_t* bodyIds, int count)
{
    using Func_t = void(__fastcall*)(void*, const std::uint32_t*, int, int);
    __try {
        ((Func_t)funcPtr)(hknpWorld, bodyIds, count, 0);
        return true;
    }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// Helper to safely call bhkNPCollisionObject::AddToWorld
static bool SafeCallAddToWorld(void* funcPtr, void* collisionObject, void* bhkWorld)
{
    using Func_t = void(__fastcall*)(void*, void*);
    __try {
        ((Func_t)funcPtr)(collisionObject, bhkWorld);
        return true;
    }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// Helper to safely call bhkNPCollisionObject::SetMotionType
static bool SafeCallSetMotionType(void* funcPtr, void* collisionObject, int motionType)
{
    using Func_t = void(__fastcall*)(void*, int);
    __try {
        ((Func_t)funcPtr)(collisionObject, motionType);
        return true;
    }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static bool SafeCallSetBodyCollisionFilterInfo(void* funcPtr, void* hknpWorld, std::uint32_t bodyId, std::uint32_t filterInfo)
{
    using Func_t = void(__fastcall*)(void*, std::uint32_t, std::uint32_t);
    __try {
        ((Func_t)funcPtr)(hknpWorld, bodyId, filterInfo);
        return true;
    }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

namespace heisenberg
{
    namespace
    {
        constexpr double kHandBodyCreationSettleDelaySeconds = 0.75;
        constexpr double kPlayerBodyRetryCooldownSeconds = 3.0;
        constexpr double kHandBodyPostCreateMoveDelaySeconds = 0.10;
        constexpr double kHandBodyCollisionEnableDelaySeconds = 0.30;
        // Use kClutter (layer 4) with proper F4VR filter format (0x02EF prefix)
        // This collides with world objects but the proxy listener handles player capsule
        // hknpGroupCollisionFilter Config<5,5,5,16>:
        //   bits 0-4:   layer (5 bits)
        //   bits 5-9:   system group (5 bits)
        //   bits 10-14: sub-system ID (5 bits)
        //   bits 15-30: sub-system don't-collide mask (16 bits)
        // Bodies in the SAME system group with matching sub-system mask DON'T collide.
        constexpr std::uint32_t kHandCollisionLayer = 4;  // kClutter
        constexpr std::uint32_t kHandCollisionDisabledBit = (1u << 14);
        constexpr std::uint32_t kSystemGroupMask = (0x1Fu << 5);   // bits 5-9
        constexpr std::uint32_t kSubSystemMask = (0x1Fu << 10);    // bits 10-14
        constexpr std::uint32_t kSubSystemDontCollideMask = (0xFFFFu << 15); // bits 15-30

        // Helper to get bhkWorld from cell (avoids REL::Relocation in __try blocks)
        using GetbhkWorld_t = void*(*)(RE::TESObjectCELL*);
        static REL::Relocation<GetbhkWorld_t> g_GetbhkWorld{ REL::Offset(0x39b070) };
        void* GetbhkWorldForCell(RE::TESObjectCELL* cell) {
            return cell ? g_GetbhkWorld(cell) : nullptr;
        }

        // Cached player collision group — read once, reused
        static std::uint32_t g_playerCollisionFilterInfo = 0;
        static bool g_playerFilterCached = false;

        std::uint32_t ReadPlayerCollisionFilterInfo()
        {
            if (g_playerFilterCached && g_playerCollisionFilterInfo != 0) {
                return g_playerCollisionFilterInfo;
            }

            // Read from the player proxy body via the body buffer
            std::uint32_t playerBodyId = heisenberg::Physics::GetPlayerBodyId();
            if (playerBodyId == 0x7FFFFFFF || playerBodyId == 0) {
                return 0;
            }

            auto* player = RE::PlayerCharacter::GetSingleton();
            if (!player || !player->parentCell) return 0;
            void* bhkWorld = GetbhkWorldForCell(player->parentCell);
            if (!bhkWorld) return 0;
            void* hknpWorld = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(bhkWorld) + 0x60);
            if (!hknpWorld) return 0;

            // Read filter from body buffer: body buffer at hknpWorld+0x20, stride 0x90, filterInfo at +0x40
            __try {
                void* bodyBuffer = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(hknpWorld) + 0x20);
                if (!bodyBuffer) return 0;
                std::uint32_t bodyIndex = playerBodyId & 0xFFFF;
                std::uint32_t filterInfo = *reinterpret_cast<std::uint32_t*>(
                    reinterpret_cast<uintptr_t>(bodyBuffer) + bodyIndex * 0x90 + 0x40);
                g_playerCollisionFilterInfo = filterInfo;
                g_playerFilterCached = true;
                spdlog::info("[HAND_COLLISION] Read player collision filter: 0x{:08X} (group={}, layer={})",
                             filterInfo, (filterInfo >> 5) & 0x1F, filterInfo & 0x1F);
                return filterInfo;
            }
            __except(EXCEPTION_EXECUTE_HANDLER) {
                return 0;
            }
        }

        std::uint32_t BuildHandCollisionFilter(bool /*isLeft*/, bool collisionEnabled)
        {
            // Start with kClutter layer
            std::uint32_t filterInfo = kHandCollisionLayer;

            // Copy player's system group so hand doesn't collide with player
            // (HIGGS pattern: same group = no collision)
            std::uint32_t playerFilter = ReadPlayerCollisionFilterInfo();
            if (playerFilter != 0) {
                // Copy system group bits (5-9) from player
                filterInfo |= (playerFilter & kSystemGroupMask);
                // Copy sub-system bits (10-14) from player
                filterInfo |= (playerFilter & kSubSystemMask);
                // Copy don't-collide mask (15-30) from player
                filterInfo |= (playerFilter & kSubSystemDontCollideMask);
            } else {
                // Fallback: use a known working filter format with disabled bit
                filterInfo = 0x02EF0004;
            }

            if (!collisionEnabled) {
                filterInfo |= kHandCollisionDisabledBit;
            }

            return filterInfo;
        }

        void ResetPlayerFilterCache()
        {
            g_playerFilterCached = false;
            g_playerCollisionFilterInfo = 0;
        }

        void MatrixToQuaternion(const RE::NiMatrix3& m, RE::NiPoint4& outQuat)
        {
            float trace = m.entry[0][0] + m.entry[1][1] + m.entry[2][2];

            if (trace > 0.0f) {
                float s = 0.5f / sqrtf(trace + 1.0f);
                outQuat.w = 0.25f / s;
                outQuat.x = (m.entry[2][1] - m.entry[1][2]) * s;
                outQuat.y = (m.entry[0][2] - m.entry[2][0]) * s;
                outQuat.z = (m.entry[1][0] - m.entry[0][1]) * s;
            } else if (m.entry[0][0] > m.entry[1][1] && m.entry[0][0] > m.entry[2][2]) {
                float s = 2.0f * sqrtf(1.0f + m.entry[0][0] - m.entry[1][1] - m.entry[2][2]);
                outQuat.w = (m.entry[2][1] - m.entry[1][2]) / s;
                outQuat.x = 0.25f * s;
                outQuat.y = (m.entry[0][1] + m.entry[1][0]) / s;
                outQuat.z = (m.entry[0][2] + m.entry[2][0]) / s;
            } else if (m.entry[1][1] > m.entry[2][2]) {
                float s = 2.0f * sqrtf(1.0f + m.entry[1][1] - m.entry[0][0] - m.entry[2][2]);
                outQuat.w = (m.entry[0][2] - m.entry[2][0]) / s;
                outQuat.x = (m.entry[0][1] + m.entry[1][0]) / s;
                outQuat.y = 0.25f * s;
                outQuat.z = (m.entry[1][2] + m.entry[2][1]) / s;
            } else {
                float s = 2.0f * sqrtf(1.0f + m.entry[2][2] - m.entry[0][0] - m.entry[1][1]);
                outQuat.w = (m.entry[1][0] - m.entry[0][1]) / s;
                outQuat.x = (m.entry[0][2] + m.entry[2][0]) / s;
                outQuat.y = (m.entry[1][2] + m.entry[2][1]) / s;
                outQuat.z = 0.25f * s;
            }
        }
    }

    // =========================================================================
    // INITIALIZATION
    // =========================================================================

    bool HandCollision::Initialize()
    {
        if (_initialized) {
            return true;
        }

        spdlog::info("[HAND_COLLISION] Physics-based hand collision system initializing...");
        
        // Clear state
        _leftHandBody.Invalidate();
        _rightHandBody.Invalidate();
        _leftContact.reset();
        _rightContact.reset();
        _bodyCreationBlockedUntil = Utils::GetTime() + kHandBodyCreationSettleDelaySeconds;
        _playerBodyRetryBlockedUntil = 0.0;

        // The custom proxy-listener vtable is still incomplete in VR.
        // During real trigger-volume callbacks the engine dispatches additional
        // listener methods beyond processConstraintsCallback, which makes the
        // synthetic listener crash inside hknpCharacterProxyInternals.
        // Keep hand collision on the safer pair-filter path until the full
        // hknpCharacterProxyListener ABI is mapped.
        spdlog::info("[HAND_COLLISION] Player proxy listener registration is disabled; using player-body pair filtering only");

        _initialized = true;
        spdlog::info("[HAND_COLLISION] Hand collision system initialized (bodies will be created on first update)");
        return true;
    }

    void HandCollision::Shutdown()
    {
        spdlog::info("[HAND_COLLISION] Shutting down hand collision system...");

        // Invalidate hand bodies — don't try to destroy them.
        // During save/load the physics world may already be torn down,
        // and calling DestroyBodies on a dead world crashes.
        {
            std::scoped_lock lock(_handBodyMutex);
            _leftHandBody.Invalidate();
            _rightHandBody.Invalidate();
        }

        _leftContact.reset();
        _rightContact.reset();
        _bodyCreationBlockedUntil = Utils::GetTime() + kHandBodyCreationSettleDelaySeconds;
        _playerBodyRetryBlockedUntil = 0.0;
        ResetPlayerFilterCache();

        _initialized = false;
    }

    // =========================================================================
    // BODY CREATION (called from HookEndUpdate)
    // =========================================================================

    void HandCollision::CreateBodiesIfNeeded(const RE::NiPoint3& leftHandPos, const RE::NiPoint3& rightHandPos)
    {
        if (!g_config.enableHandCollision || !g_config.usePhysicsHandBodies) {
            return;
        }

        if (!_initialized) {
            Initialize();
        }

        auto player = RE::PlayerCharacter::GetSingleton();
        if (!player || !player->parentCell) {
            return;
        }

        void* hknpWorld = GetCurrentHknpWorld();
        void* bhkWorld = GetCurrentBhkWorld();
        if (!hknpWorld || !bhkWorld) {
            return;
        }

        // Check if bodies need creation
        bool needsCreation = false;
        {
            std::scoped_lock lock(_handBodyMutex);
            bool worldChanged = (_leftHandBody.IsValid() && _leftHandBody.hknpWorld != hknpWorld) ||
                                (_rightHandBody.IsValid() && _rightHandBody.hknpWorld != hknpWorld);
            if (worldChanged) {
                spdlog::info("[HAND_COLLISION] Physics world changed — invalidating old hand bodies (old world already cleaned them up)");
                // Don't call DestroyPhysicsHandBody — the old world is gone.
                // Just reset our tracking state.
                _leftHandBody.Invalidate();
                _rightHandBody.Invalidate();
                ResetPlayerFilterCache();
            }
            needsCreation = !_leftHandBody.IsValid() || !_rightHandBody.IsValid();
        }

        if (!needsCreation) {
            return;
        }

        if (!CanCreatePhysicsHandBodiesNow()) {
            return;
        }

        std::scoped_lock lock(_handBodyMutex);
        Physics::WorldWriteLock worldLock(reinterpret_cast<RE::bhkWorld*>(bhkWorld));
        if (!worldLock.IsLocked()) {
            spdlog::warn("[HAND_COLLISION] Failed to acquire world write lock; skipping physics hand body creation");
            return;
        }

        if (!_leftHandBody.IsValid()) {
            spdlog::info("[HAND_COLLISION] Creating LEFT hand body at ({:.1f}, {:.1f}, {:.1f})",
                         leftHandPos.x, leftHandPos.y, leftHandPos.z);
            if (!CreatePhysicsHandBody(_leftHandBody, hknpWorld, bhkWorld, leftHandPos, true)) {
                return;
            }
        }

        if (!_rightHandBody.IsValid()) {
            spdlog::info("[HAND_COLLISION] Creating RIGHT hand body at ({:.1f}, {:.1f}, {:.1f})",
                         rightHandPos.x, rightHandPos.y, rightHandPos.z);
            if (!CreatePhysicsHandBody(_rightHandBody, hknpWorld, bhkWorld, rightHandPos, false)) {
                return;
            }
        }
    }

    // =========================================================================
    // PAIR FILTER (called from EndUpdate — no physics locks)
    // =========================================================================

    void HandCollision::ApplyPlayerPairFilterIfNeeded()
    {
        if (!_initialized || !g_config.enableHandCollision || !g_config.usePhysicsHandBodies) {
            return;
        }

        std::scoped_lock lock(_handBodyMutex);

        // Skip if both hands already have the pair filter applied
        if ((!_leftHandBody.IsValid() || _leftHandBody.playerPairFilterApplied) &&
            (!_rightHandBody.IsValid() || _rightHandBody.playerPairFilterApplied)) {
            return;
        }

        std::uint32_t playerBodyId = Physics::GetPlayerBodyId();
        if (playerBodyId == 0x7FFFFFFF || playerBodyId == 0) {
            return;
        }

        void* hknpWorld = GetCurrentHknpWorld();
        if (!hknpWorld) {
            return;
        }

        if (_leftHandBody.IsValid() && !_leftHandBody.playerPairFilterApplied) {
            Physics::DisableCollisionBetween(hknpWorld, _leftHandBody.bodyId, playerBodyId);
            _leftHandBody.playerPairFilterApplied = true;
            spdlog::info("[HAND_COLLISION] Applied player pair filter to LEFT hand body 0x{:08X} vs player 0x{:08X}",
                         _leftHandBody.bodyId, playerBodyId);
        }

        if (_rightHandBody.IsValid() && !_rightHandBody.playerPairFilterApplied) {
            Physics::DisableCollisionBetween(hknpWorld, _rightHandBody.bodyId, playerBodyId);
            _rightHandBody.playerPairFilterApplied = true;
            spdlog::info("[HAND_COLLISION] Applied player pair filter to RIGHT hand body 0x{:08X} vs player 0x{:08X}",
                         _rightHandBody.bodyId, playerBodyId);
        }

        // Now enable collision on hand bodies (was staged OFF during creation).
        // Safe to do here because the player pair filter is already applied, so
        // the hand bodies won't punch through the player capsule as they turn on.
        // Flipping the DISABLED bit off on the filter lets the KEYFRAMED hand
        // body transfer its velocity to dynamic clutter through the Havok
        // solver — the missing link for HIGGS-style "hands push objects".
        if (_leftHandBody.IsValid() && !_leftHandBody.collisionEnabled) {
            SetHandCollisionEnabled(_leftHandBody, true);
        }
        if (_rightHandBody.IsValid() && !_rightHandBody.collisionEnabled) {
            SetHandCollisionEnabled(_rightHandBody, true);
        }
    }

    // =========================================================================
    // MAIN UPDATE (called from post-physics hook — position updates only)
    // =========================================================================

    void HandCollision::Update(const RE::NiPoint3& leftHandPos, const RE::NiPoint3& rightHandPos,
                                const RE::NiPoint3& leftHandVel, const RE::NiPoint3& rightHandVel,
                                const RE::NiMatrix3& leftHandRot, const RE::NiMatrix3& rightHandRot,
                                float deltaTime)
    {
        if (!g_config.enableHandCollision) {
            return;
        }

        // Store hand state
        _leftHandPos = leftHandPos;
        _rightHandPos = rightHandPos;
        _leftHandVel = leftHandVel;
        _rightHandVel = rightHandVel;

        // Position-only updates for existing bodies (safe from post-physics hook)
        void* hknpWorld = GetCurrentHknpWorld();
        if (g_config.usePhysicsHandBodies && hknpWorld) {
            std::scoped_lock lock(_handBodyMutex);
            if (_leftHandBody.IsValid() && _leftHandBody.hknpWorld == hknpWorld) {
                UpdateHandBodyPosition(_leftHandBody, leftHandPos, leftHandRot, deltaTime);
            }
            if (_rightHandBody.IsValid() && _rightHandBody.hknpWorld == hknpWorld) {
                UpdateHandBodyPosition(_rightHandBody, rightHandPos, rightHandRot, deltaTime);
            }
        }

        // Proximity-based collision
        CheckProximityCollisions(leftHandPos, leftHandVel, true);
        CheckProximityCollisions(rightHandPos, rightHandVel, false);
    }

#if 0  // OLD UPDATE CODE — body creation/pair filter moved to HookPlayerCharacterUpdate
        if (false && hknpWorld && bhkWorld) {
            std::uint32_t playerBodyId = 0x7FFFFFFF;
            bool needsPlayerCollisionState = false;
            bool haveHandBodies = false;

            {
                std::scoped_lock lock(_handBodyMutex);

                bool worldChanged = (_leftHandBody.IsValid() && _leftHandBody.hknpWorld != hknpWorld) ||
                                    (_rightHandBody.IsValid() && _rightHandBody.hknpWorld != hknpWorld);

                if (worldChanged) {
                    spdlog::info("[HAND_COLLISION] Physics world changed, recreating hand bodies");
                    DestroyPhysicsHandBody(_leftHandBody);
                    DestroyPhysicsHandBody(_rightHandBody);
                }

                needsPlayerCollisionState =
                    (_leftHandBody.IsValid() && !_leftHandBody.playerPairFilterApplied) ||
                    (_rightHandBody.IsValid() && !_rightHandBody.playerPairFilterApplied);

                haveHandBodies = _leftHandBody.IsValid() || _rightHandBody.IsValid();
            }

            const bool shouldResolvePlayerCollisionNow =
                needsPlayerCollisionState && (!haveHandBodies || now >= _playerBodyRetryBlockedUntil);

            if (CanCreatePhysicsHandBodiesNow(shouldResolvePlayerCollisionNow ? &playerBodyId : nullptr)) {
                const bool playerCollisionReady =
                    playerBodyId != 0 && playerBodyId != 0x7FFFFFFF && playerBodyId != 0xFFFFFFFF;

                if (playerCollisionReady) {
                    _playerBodyRetryBlockedUntil = 0.0;
                } else if (needsPlayerCollisionState && shouldResolvePlayerCollisionNow) {
                    _playerBodyRetryBlockedUntil = now + kPlayerBodyRetryCooldownSeconds;
                }

                if (!playerCollisionReady && shouldResolvePlayerCollisionNow && needsPlayerCollisionState) {
                    static double lastUnfilteredHandBodyLogTime = 0.0;
                    if (now - lastUnfilteredHandBodyLogTime >= 1.0) {
                        spdlog::warn("[HAND_COLLISION] No player controller body is exposed in this VR runtime; keeping physics hand bodies non-collidable until player filtering is available");
                        lastUnfilteredHandBodyLogTime = now;
                    }
                }

                if (GetCurrentBhkWorld() == bhkWorld && GetCurrentHknpWorld() == hknpWorld) {
                    std::scoped_lock lock(_handBodyMutex);
                    auto& proxyListener = PlayerCharacterProxyListener::GetSingleton();

                    if (_leftHandBody.IsValid() && !_leftHandBody.proxyRegistered) {
                        proxyListener.RegisterHandBodyId(_leftHandBody.bodyId);
                        _leftHandBody.proxyRegistered = true;
                    }

                    if (_rightHandBody.IsValid() && !_rightHandBody.proxyRegistered) {
                        proxyListener.RegisterHandBodyId(_rightHandBody.bodyId);
                        _rightHandBody.proxyRegistered = true;
                    }

                    if (_leftHandBody.IsValid() && !_leftHandBody.playerPairFilterApplied && playerCollisionReady) {
                        if (!TryDisableCollisionWithPlayer(_leftHandBody, playerBodyId)) {
                            static double lastLeftPairFilterLogTime = 0.0;
                            if (now - lastLeftPairFilterLogTime >= 1.0) {
                                spdlog::warn("[HAND_COLLISION] Waiting to apply player collision filter to LEFT hand body 0x{:08X}",
                                             _leftHandBody.bodyId);
                                lastLeftPairFilterLogTime = now;
                            }
                        }
                    }

                    if (_rightHandBody.IsValid() && !_rightHandBody.playerPairFilterApplied && playerCollisionReady) {
                        if (!TryDisableCollisionWithPlayer(_rightHandBody, playerBodyId)) {
                            static double lastRightPairFilterLogTime = 0.0;
                            if (now - lastRightPairFilterLogTime >= 1.0) {
                                spdlog::warn("[HAND_COLLISION] Waiting to apply player collision filter to RIGHT hand body 0x{:08X}",
                                             _rightHandBody.bodyId);
                                lastRightPairFilterLogTime = now;
                            }
                        }
                    }
                }

                if (GetCurrentBhkWorld() == bhkWorld && GetCurrentHknpWorld() == hknpWorld) {
                    std::scoped_lock lock(_handBodyMutex);
                    const bool leftReadyForMovement =
                        _leftHandBody.IsValid() &&
                        (_leftHandBody.playerPairFilterApplied || !playerCollisionReady) &&
                        (now - _leftHandBody.createdTime >= kHandBodyPostCreateMoveDelaySeconds);
                    const bool rightReadyForMovement =
                        _rightHandBody.IsValid() &&
                        (_rightHandBody.playerPairFilterApplied || !playerCollisionReady) &&
                        (now - _rightHandBody.createdTime >= kHandBodyPostCreateMoveDelaySeconds);

                    if (!leftReadyForMovement && !rightReadyForMovement) {
                        if (_leftHandBody.IsValid() || _rightHandBody.IsValid()) {
                            static double lastPostCreateDelayLogTime = 0.0;
                            if (now - lastPostCreateDelayLogTime >= 1.0) {
                                spdlog::info("[HAND_COLLISION] Waiting briefly before first keyframe update of newly created hand bodies");
                                lastPostCreateDelayLogTime = now;
                            }
                        }
                    } else {
                        Physics::WorldWriteLock moveWorldLock(reinterpret_cast<RE::bhkWorld*>(bhkWorld));
                        if (!moveWorldLock.IsLocked()) {
                            spdlog::warn("[HAND_COLLISION] Failed to reacquire world write lock; skipping hand body movement");
                        } else {
                            if (leftReadyForMovement) {
                                UpdateHandBodyPosition(_leftHandBody, leftHandPos, leftHandRot, deltaTime);

                                if (!_leftHandBody.collisionEnabled &&
                                    _leftHandBody.playerPairFilterApplied &&
                                    (now - _leftHandBody.createdTime >= kHandBodyCollisionEnableDelaySeconds)) {
                                    SetHandCollisionEnabled(_leftHandBody, true);
                                }
                            }

                            if (rightReadyForMovement) {
                                UpdateHandBodyPosition(_rightHandBody, rightHandPos, rightHandRot, deltaTime);

                                if (!_rightHandBody.collisionEnabled &&
                                    _rightHandBody.playerPairFilterApplied &&
                                    (now - _rightHandBody.createdTime >= kHandBodyCollisionEnableDelaySeconds)) {
                                    SetHandCollisionEnabled(_rightHandBody, true);
                                }
                            }

                            if ((_leftHandBody.IsValid() && !_leftHandBody.collisionEnabled && !_leftHandBody.playerPairFilterApplied) ||
                                (_rightHandBody.IsValid() && !_rightHandBody.collisionEnabled && !_rightHandBody.playerPairFilterApplied)) {
                                static double lastCollisionDeferralLogTime = 0.0;
                                if (now - lastCollisionDeferralLogTime >= 1.0) {
                                    if (playerCollisionReady) {
                                        spdlog::warn("[HAND_COLLISION] Keeping native hand-body collision staged OFF until player pair filtering is available; proximity fallback remains active");
                                    } else {
                                        spdlog::warn("[HAND_COLLISION] Keeping native hand-body collision staged OFF because no player controller body is exposed in this VR runtime; proximity fallback remains active");
                                    }
                                    lastCollisionDeferralLogTime = now;
                                }
                            }
                        }
                    }
                }
            }
        }

        // Proximity-based collision as supplement
        CheckProximityCollisions(leftHandPos, leftHandVel, true);
        CheckProximityCollisions(rightHandPos, rightHandVel, false);
    }

#endif  // OLD UPDATE CODE

    // Old Update body creation code also disabled below
        ConstraintFunctions::PhysicsSystemDataCtor(systemDataMem);

        void* materialMem = _aligned_malloc(sizeof(hknpMaterialDescriptor), 16);
        if (!materialMem) {
            spdlog::error("[HAND_COLLISION] Failed to allocate hknpMaterialDescriptor");
            _aligned_free(systemDataMem);
            return false;
        }
        std::memset(materialMem, 0, sizeof(hknpMaterialDescriptor));

        void* bodyCinfoMem = _aligned_malloc(sizeof(hknpBodyCinfo), 16);
        if (!bodyCinfoMem) {
            spdlog::error("[HAND_COLLISION] Failed to allocate hknpBodyCinfo");
            _aligned_free(materialMem);
            _aligned_free(systemDataMem);
            return false;
        }
        auto* bodyCinfo = reinterpret_cast<hknpBodyCinfo*>(bodyCinfoMem);
        ConstraintFunctions::BodyCinfoCtor(bodyCinfo);
        bodyCinfo->shape = shape;
        bodyCinfo->position = RE::NiPoint4(
            position.x * HAVOK_WORLD_SCALE_COLLISION,
            position.y * HAVOK_WORLD_SCALE_COLLISION,
            position.z * HAVOK_WORLD_SCALE_COLLISION,
            0.0f
        );
        bodyCinfo->orientation = RE::NiPoint4(0.0f, 0.0f, 0.0f, 1.0f);
        bodyCinfo->qualityId = static_cast<std::uint8_t>(hknpMotionPropertiesId::KEYFRAMED);
        bodyCinfo->materialId = 0;
        bodyCinfo->collisionFilterInfo = filterInfo;
        bodyCinfo->flags = 0;

        spdlog::info("[HAND_COLLISION] Body cinfo: qualityId={}, filterInfo=0x{:08X}, shape={:p}",
                     bodyCinfo->qualityId, filterInfo, bodyCinfo->shape);
        spdlog::info("[HAND_COLLISION] hknpWorld={:p}, bhkWorld={:p}", hknpWorld, bhkWorld);

        std::uint8_t* systemDataBytes = reinterpret_cast<std::uint8_t*>(systemDataMem);
        *reinterpret_cast<void**>(systemDataBytes + 0x10) = materialMem;
        *reinterpret_cast<std::uint32_t*>(systemDataBytes + 0x18) = 1;
        *reinterpret_cast<std::uint32_t*>(systemDataBytes + 0x1C) = 0x80000001;
        *reinterpret_cast<void**>(systemDataBytes + 0x40) = bodyCinfo;
        *reinterpret_cast<std::uint32_t*>(systemDataBytes + 0x48) = 1;
        *reinterpret_cast<std::uint32_t*>(systemDataBytes + 0x4C) = 0x80000001;

        // =====================================================================
        // 3. CREATE BETHESDA WRAPPERS AND ADD BODY TO WORLD
        // =====================================================================

        void* physicsSystemMem = _aligned_malloc(0x30, 16);
        if (!physicsSystemMem) {
            spdlog::error("[HAND_COLLISION] Failed to allocate bhkPhysicsSystem");
            _aligned_free(bodyCinfoMem);
            _aligned_free(materialMem);
            _aligned_free(systemDataMem);
            return false;
        }
        std::memset(physicsSystemMem, 0, 0x30);
        ConstraintFunctions::BhkPhysicsSystemCtor(physicsSystemMem, systemDataMem);

        alignas(16) std::uint8_t identityTransform[0x40] = {};
        reinterpret_cast<float*>(identityTransform)[0] = 1.0f;
        reinterpret_cast<float*>(identityTransform)[5] = 1.0f;
        reinterpret_cast<float*>(identityTransform)[10] = 1.0f;
        reinterpret_cast<float*>(identityTransform)[15] = 1.0f;

        spdlog::info("[HAND_COLLISION] Calling BhkPhysicsSystemCreateInstance...");
        ConstraintFunctions::BhkPhysicsSystemCreateInstance(physicsSystemMem, bhkWorld, identityTransform);

        void* collisionObjMem = _aligned_malloc(0x30, 16);
        if (!collisionObjMem) {
            spdlog::error("[HAND_COLLISION] Failed to allocate bhkNPCollisionObject");
            _aligned_free(physicsSystemMem);
            _aligned_free(bodyCinfoMem);
            _aligned_free(materialMem);
            _aligned_free(systemDataMem);
            return false;
        }
        std::memset(collisionObjMem, 0, 0x30);
        ConstraintFunctions::BhkNPCollisionObjectCtor(collisionObjMem, 0, physicsSystemMem);

        if (!SafeCallAddToWorld((void*)ConstraintFunctions::BhkNPCollisionObjectAddToWorld.address(), collisionObjMem, bhkWorld)) {
            spdlog::error("[HAND_COLLISION] bhkNPCollisionObject::AddToWorld CRASHED");
            _aligned_free(collisionObjMem);
            _aligned_free(physicsSystemMem);
            _aligned_free(bodyCinfoMem);
            _aligned_free(materialMem);
            _aligned_free(systemDataMem);
            return false;
        }

        std::uint32_t bodyId = 0x7FFFFFFF;
        ConstraintFunctions::BhkPhysicsSystemGetBodyId(physicsSystemMem, &bodyId, 0);
        if (bodyId == 0x7FFFFFFF) {
            spdlog::error("[HAND_COLLISION] Failed to get body ID from bhkPhysicsSystem");
            _aligned_free(collisionObjMem);
            _aligned_free(physicsSystemMem);
            _aligned_free(bodyCinfoMem);
            _aligned_free(materialMem);
            _aligned_free(systemDataMem);
            return false;
        }

        if (!SafeCallSetMotionType((void*)ConstraintFunctions::BhkNPCollisionObjectSetMotionType.address(), collisionObjMem, 2)) {
            spdlog::warn("[HAND_COLLISION] SetMotionType(KEYFRAMED) threw SEH exception - continuing");
        }

        ConstraintFunctions::hknpWorld_commitAddBodies(hknpWorld);
        ConstraintFunctions::hknpWorld_activateBody(hknpWorld, bodyId);

        spdlog::info("[HAND_COLLISION] SUCCESS! Created {} hand body with ID: 0x{:08X}",
                     isLeft ? "LEFT" : "RIGHT", bodyId);

        // =====================================================================
        // 4. STORE RESULTS
        // =====================================================================

        handBody.bodyId = bodyId;
        handBody.shape = shape;
        handBody.hknpWorld = hknpWorld;
        handBody.bhkWorld = bhkWorld;
        handBody.physicsSystem = physicsSystemMem;
        handBody.collisionObject = collisionObjMem;
        handBody.alignedSystemDataMem = systemDataMem;
        handBody.alignedBodyCinfoMem = bodyCinfoMem;
        handBody.alignedMaterialMem = materialMem;
        handBody.alignedPhysicsSystemMem = physicsSystemMem;
        handBody.alignedCollisionObjMem = collisionObjMem;
        handBody.valid = true;
        handBody.collisionEnabled = false;
        handBody.proxyRegistered = false;
        handBody.playerPairFilterApplied = false;
        handBody.collisionFilterInfo = filterInfo;
        handBody.createdTime = Utils::GetTime();

        spdlog::info("[HAND_COLLISION] Created {} hand body 0x{:08X} with collision staged OFF (filter=0x{:08X})",
                     isLeft ? "LEFT" : "RIGHT", bodyId, filterInfo);
        
        return true;
    }

    void HandCollision::DestroyPhysicsHandBody(PhysicsHandBody& handBody)
    {
        if (!handBody.IsValid()) {
            return;
        }
        
        spdlog::info("[HAND_COLLISION] Destroying hand body id=0x{:08X}", handBody.bodyId);

        PlayerCharacterProxyListener::GetSingleton().UnregisterHandBodyId(handBody.bodyId);
        
        if (handBody.hknpWorld) {
            std::uint32_t bodyId = handBody.bodyId;
            SafeCallDestroyBodies((void*)ConstraintFunctions::DestroyBodies.address(), handBody.hknpWorld, &bodyId, 1);
        }

        if (handBody.alignedCollisionObjMem) _aligned_free(handBody.alignedCollisionObjMem);
        if (handBody.alignedPhysicsSystemMem) _aligned_free(handBody.alignedPhysicsSystemMem);
        if (handBody.alignedBodyCinfoMem) _aligned_free(handBody.alignedBodyCinfoMem);
        if (handBody.alignedMaterialMem) _aligned_free(handBody.alignedMaterialMem);
        if (handBody.alignedSystemDataMem) _aligned_free(handBody.alignedSystemDataMem);
        
        handBody.Invalidate();
    }

    void HandCollision::UpdateHandBodyPosition(PhysicsHandBody& handBody, 
                                                const RE::NiPoint3& position,
                                                const RE::NiMatrix3& rotation,
                                                float deltaTime)
    {
        if (!handBody.IsValid() || !handBody.hknpWorld) {
            return;
        }
        
        // Static-lifetime aligned scratch — MSVC doesn't reliably honor
        // alignas(16) on stack NiPoint4 locals; statics do respect alignas.
        struct alignas(16) UpdatePosScratch {
            float hkPosition[4];
            float hkOrientation[4];
        };
        static UpdatePosScratch s_updScratch;
        s_updScratch.hkPosition[0] = position.x * HAVOK_WORLD_SCALE_COLLISION;
        s_updScratch.hkPosition[1] = position.y * HAVOK_WORLD_SCALE_COLLISION;
        s_updScratch.hkPosition[2] = position.z * HAVOK_WORLD_SCALE_COLLISION;
        s_updScratch.hkPosition[3] = 0.0f;

        auto& hkOrient = *reinterpret_cast<RE::NiPoint4*>(s_updScratch.hkOrientation);
        MatrixToQuaternion(rotation, hkOrient);

        float invDeltaTime = (deltaTime > 0.0001f) ? (1.0f / deltaTime) : 90.0f;
        if (!SafeCallApplyHardKeyFrame(
                (void*)ConstraintFunctions::ApplyHardKeyFrameBodyId.address(),
                handBody.hknpWorld,
                handBody.bodyId,
                reinterpret_cast<RE::NiPoint4*>(s_updScratch.hkPosition),
                reinterpret_cast<RE::NiPoint4*>(s_updScratch.hkOrientation),
                invDeltaTime)) {
            spdlog::error("[HAND_COLLISION] Exception in applyHardKeyFrame");
        }
    }

    void HandCollision::SetHandCollisionEnabled(PhysicsHandBody& handBody, bool enabled)
    {
        if (!handBody.IsValid()) {
            return;
        }

        if (!handBody.hknpWorld || handBody.collisionEnabled == enabled) {
            return;
        }

        using SetFilterFn = void(__fastcall*)(void*, std::uint32_t, std::uint32_t);
        static REL::Relocation<SetFilterFn> setFilter{ REL::Offset(0x153af00) };

        std::uint32_t newFilter = handBody.collisionFilterInfo;
        if (enabled) {
            newFilter &= ~kHandCollisionDisabledBit;
        } else {
            newFilter |= kHandCollisionDisabledBit;
        }
        if (!SafeCallSetBodyCollisionFilterInfo((void*)setFilter.address(), handBody.hknpWorld, handBody.bodyId, newFilter)) {
            spdlog::warn("[HAND_COLLISION] Failed to {} collision for hand body 0x{:08X}",
                         enabled ? "enable" : "disable", handBody.bodyId);
            return;
        }

        handBody.collisionFilterInfo = newFilter;
        handBody.collisionEnabled = enabled;

        spdlog::info("[HAND_COLLISION] Collision {} for hand body 0x{:08X} (filter=0x{:08X})",
                     enabled ? "ENABLED" : "DISABLED", handBody.bodyId, newFilter);
    }

    bool HandCollision::ResolveReadyPlayerCollisionState(std::uint32_t& playerBodyId) const
    {
        playerBodyId = Physics::GetPlayerBodyId();
        if (playerBodyId == 0 || playerBodyId == 0x7FFFFFFF || playerBodyId == 0xFFFFFFFF) {
            static double lastBodyWaitLogTime = 0.0;
            double now = Utils::GetTime();
            if (now - lastBodyWaitLogTime >= 1.0) {
                spdlog::info("[HAND_COLLISION] Waiting for player controller body before applying player pair filtering to physics hand bodies");
                lastBodyWaitLogTime = now;
            }
            return false;
        }

        return true;
    }

    bool HandCollision::CanCreatePhysicsHandBodiesNow(std::uint32_t* playerBodyId) const
    {
        double now = Utils::GetTime();
        if (MenuChecker::GetSingleton().IsLoading()) {
            static double lastLoadingLogTime = 0.0;
            if (now - lastLoadingLogTime >= 0.5) {
                spdlog::info("[HAND_COLLISION] Delaying physics hand body creation while LoadingMenu is open");
                lastLoadingLogTime = now;
            }
            return false;
        }

        if (now < _bodyCreationBlockedUntil) {
            static double lastSettleLogTime = 0.0;
            if (now - lastSettleLogTime >= 0.5) {
                spdlog::info("[HAND_COLLISION] Delaying physics hand body creation for post-load settle window ({:.0f} ms remaining)",
                             (_bodyCreationBlockedUntil - now) * 1000.0);
                lastSettleLogTime = now;
            }
            return false;
        }

        if (playerBodyId) {
            std::uint32_t resolvedPlayerBodyId = 0x7FFFFFFF;
            if (ResolveReadyPlayerCollisionState(resolvedPlayerBodyId)) {
                *playerBodyId = resolvedPlayerBodyId;
            } else {
                *playerBodyId = 0x7FFFFFFF;
            }
        }

        return true;
    }

    bool HandCollision::TryDisableCollisionWithPlayer(PhysicsHandBody& handBody, std::uint32_t playerBodyId)
    {
        if (!handBody.IsValid() || !handBody.hknpWorld || handBody.playerPairFilterApplied) {
            return handBody.playerPairFilterApplied;
        }

        if (playerBodyId == 0 || playerBodyId == 0x7FFFFFFF || playerBodyId == 0xFFFFFFFF || playerBodyId == handBody.bodyId) {
            return false;
        }

        spdlog::info("[HAND_COLLISION] Calling DisableCollisionsBetween for hand body 0x{:08X} against player body 0x{:08X}",
                     handBody.bodyId, playerBodyId);
        Physics::DisableCollisionsBetween(handBody.hknpWorld, handBody.bodyId, playerBodyId);
        handBody.playerPairFilterApplied = true;

        spdlog::info("[HAND_COLLISION] Disabled player collision for hand body 0x{:08X} against player body 0x{:08X}",
                     handBody.bodyId, playerBodyId);
        return true;
    }

    // =========================================================================
    // WORLD ACCESS
    // =========================================================================

    void* HandCollision::GetCurrentHknpWorld()
    {
        auto player = RE::PlayerCharacter::GetSingleton();
        if (!player || !player->parentCell) {
            return nullptr;
        }
        
        auto* cell = player->parentCell;
        using GetbhkWorld_t = void*(*)(RE::TESObjectCELL*);
        static REL::Relocation<GetbhkWorld_t> GetbhkWorld{ REL::Offset(0x39b070) };
        
        void* bhkWorld = GetbhkWorld(cell);
        if (!bhkWorld) {
            return nullptr;
        }
        
        void* hknpWorld = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(bhkWorld) + 0x60);
        return hknpWorld;
    }

    void* HandCollision::GetCurrentBhkWorld()
    {
        auto player = RE::PlayerCharacter::GetSingleton();
        if (!player || !player->parentCell) {
            return nullptr;
        }
        
        auto* cell = player->parentCell;
        using GetbhkWorld_t = void*(*)(RE::TESObjectCELL*);
        static REL::Relocation<GetbhkWorld_t> GetbhkWorld{ REL::Offset(0x39b070) };
        
        return GetbhkWorld(cell);
    }

    // =========================================================================
    // COLLISION HANDLING
    // =========================================================================

    void HandCollision::CheckProximityCollisions(const RE::NiPoint3& handPos,
                                                  const RE::NiPoint3& handVel,
                                                  bool isLeft)
    {
        auto player = RE::PlayerCharacter::GetSingleton();
        if (!player) return;

        float collisionRadius = g_config.handCollisionRadius;
        
        if (isLeft) {
            _leftContact.reset();
        } else {
            _rightContact.reset();
        }

        auto nearby = Physics::GetObjectsInRadius(handPos, collisionRadius, player);
        for (auto* refr : nearby) {
            if (refr && Physics::IsGrabbable(refr)) {
                if (isLeft) {
                    _leftContact = RE::ObjectRefHandle(refr);
                } else {
                    _rightContact = RE::ObjectRefHandle(refr);
                }
                
                float velMag = sqrtf(handVel.x * handVel.x + handVel.y * handVel.y + handVel.z * handVel.z);
                if (velMag > g_config.handPushVelocityThreshold) {
                    ApplyPushForce(refr, handPos, handVel, 1.0f / 90.0f);
                }
                break;
            }
        }
    }

    // Helper to safely cast collision objects - follows bhkNPCollisionProxyObject to its target
    // since proxy objects don't have their own physics system
    static RE::bhkNPCollisionObject* SafeCastCollisionObject(RE::NiCollisionObject* collObj)
    {
        if (!collObj) return nullptr;
        
        auto* rtti = collObj->GetRTTI();
        if (!rtti || !rtti->GetName()) {
            return nullptr;
        }
        
        const char* typeName = rtti->GetName();
        
        if (std::strcmp(typeName, "bhkNPCollisionProxyObject") == 0) {
            spdlog::trace("[HAND_COLLISION] Found ProxyObject - following target pointer");
            RE::bhkNPCollisionObject* target = GetProxyTarget(collObj);
            if (!target) {
                spdlog::trace("[HAND_COLLISION] ProxyObject has null target!");
                return nullptr;
            }
            return target;
        }
        
        if (std::strcmp(typeName, "bhkNPCollisionObject") == 0) {
            return reinterpret_cast<RE::bhkNPCollisionObject*>(collObj);
        }
        
        for (auto iter = rtti; iter; iter = iter->GetBaseRTTI()) {
            if (iter->GetName() && std::strcmp(iter->GetName(), "bhkNPCollisionObject") == 0) {
                return reinterpret_cast<RE::bhkNPCollisionObject*>(collObj);
            }
        }
        
        return nullptr;
    }

    void HandCollision::ApplyPushForce(RE::TESObjectREFR* refr, const RE::NiPoint3& handPos,
                                        const RE::NiPoint3& handVel, float /*deltaTime*/)
    {
        if (!refr) return;

        // Get the collision object
        auto* node = refr->Get3D();
        if (!node) return;

        RE::bhkNPCollisionObject* colObj = nullptr;
        
        // Try to get collision object from the node directly - with safe casting
        if (node->collisionObject) {
            colObj = SafeCastCollisionObject(node->collisionObject.get());
        }
        
        // If not found, try children (for NiNode)
        if (!colObj && node->IsNode()) {
            auto* asNode = static_cast<RE::NiNode*>(node);
            // Safety bound to prevent infinite loop if children array is corrupted
            uint32_t childCount = asNode->children.size();
            if (childCount > 100) childCount = 100;
            for (uint32_t i = 0; i < childCount; ++i) {
                auto* child = asNode->children[i].get();
                if (child && child->collisionObject) {
                    colObj = SafeCastCollisionObject(child->collisionObject.get());
                    if (colObj) break;
                }
            }
        }

        if (!colObj) return;

        // Validate physics system
        if (!colObj->spSystem) {
            spdlog::trace("[HAND_COLLISION] Object {:08X} has no physics system, skipping push", refr->formID);
            return;
        }

        // Apply velocity in direction hand is moving
        float pushMultiplier = g_config.handPushForceMultiplier;
        struct alignas(16) PushScratch { float pushVel[4]; };
        static PushScratch s_pushScratch;
        s_pushScratch.pushVel[0] = handVel.x * HAVOK_WORLD_SCALE_COLLISION * pushMultiplier;
        s_pushScratch.pushVel[1] = handVel.y * HAVOK_WORLD_SCALE_COLLISION * pushMultiplier;
        s_pushScratch.pushVel[2] = handVel.z * HAVOK_WORLD_SCALE_COLLISION * pushMultiplier;
        s_pushScratch.pushVel[3] = 0.0f;
        auto& pushVel = *reinterpret_cast<RE::NiPoint4*>(s_pushScratch.pushVel);

        if (CollisionFunctions::IsCollisionObjectValid(colObj)) {
            CollisionFunctions::SetLinearVelocity(colObj, pushVel);
            
            spdlog::trace("[HAND_COLLISION] Pushed object {:08X} with vel ({:.1f}, {:.1f}, {:.1f})",
                          refr->formID, handVel.x, handVel.y, handVel.z);
        }
    }

    // =========================================================================
    // ACCESSORS
    // =========================================================================

    bool HandCollision::IsInContact(bool isLeft) const
    {
        const auto& handle = isLeft ? _leftContact : _rightContact;
        return static_cast<bool>(handle);
    }

    RE::TESObjectREFR* HandCollision::GetContactObject(bool isLeft) const
    {
        const auto& handle = isLeft ? _leftContact : _rightContact;
        if (!handle) return nullptr;
        RE::NiPointer<RE::TESObjectREFR> refPtr = handle.get();
        return refPtr.get();
    }

    const PhysicsHandBody& HandCollision::GetHandBody(bool isLeft) const
    {
        return isLeft ? _leftHandBody : _rightHandBody;
    }

    void HandCollision::TriggerCollisionHaptics(bool isLeft, float intensity, float duration)
    {
        if (!g_config.enableHandCollisionHaptics) {
            return;
        }

        // Map (intensity, duration) to SteamVR's TriggerHapticPulse duration.
        // Havok gives us a rough mass × speed product via ProcessHandCollision;
        // TriggerHapticPulse accepts microseconds (max ~3999 per pulse). Scale
        // the product into 300–3500µs so that a light tap is a gentle click and
        // a heavy impact buzzes more firmly without saturating the controller.
        float product = std::max(0.0f, intensity) * std::max(0.0f, duration);
        float scaled = 300.0f + product * g_config.handCollisionHapticScale;
        if (scaled > 3500.0f) scaled = 3500.0f;
        if (scaled < 200.0f) scaled = 200.0f;

        g_vrInput.TriggerHaptic(isLeft, static_cast<unsigned short>(scaled));
    }
}
#endif

// =====================================================================
// CLEAN HAND COLLISION IMPLEMENTATION — ROCK-style patterns
// Based on brunocatani/ROCK (working F4VR hand collision mod)
// =====================================================================

namespace heisenberg
{
    // Scale: 1 Havok unit = 70 game units (ROCK confirmed)
    constexpr float kGameToHavok = 1.0f / 70.0f;
    constexpr float kHavokToGame = 70.0f;

    // Layer 43 for hand collision (ROCK uses 43)
    constexpr std::uint32_t kHandLayer = 43;
    constexpr std::uint32_t kHandGroup = 11;

    // Register layer 43 in collision filter matrix
    static void RegisterHandLayer(void* hknpWorld)
    {
        if (!hknpWorld) return;
        void* modMgr = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(hknpWorld) + 0x150);
        if (!modMgr) return;
        void* filterPtr = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(modMgr) + 0x5E8);
        if (!filterPtr) return;
        uint64_t* matrix = reinterpret_cast<uint64_t*>(reinterpret_cast<uintptr_t>(filterPtr) + 0x1A0);

        uint64_t mask = 0xFFFFFFFFFFFFFFFFULL;
        mask &= ~(1ULL << 15);  // NonCollidable
        mask &= ~(1ULL << 43);  // self
        mask &= ~(1ULL << 30);  // CharController
        if (matrix[43] != mask) {
            matrix[43] = mask;
            for (int i = 0; i < 48; i++) {
                if (i == 15 || i == 43 || i == 30) continue;
                matrix[i] |= (1ULL << 43);
            }
            spdlog::info("[HAND_COLLISION] Registered layer 43 in collision filter");
        }
    }

    // Get bhkWorld and hknpWorld from player cell
    static bool GetWorlds(void*& outBhkWorld, void*& outHknpWorld)
    {
        auto* player = RE::PlayerCharacter::GetSingleton();
        if (!player || !player->parentCell) return false;
        using GetBhk_t = void*(*)(RE::TESObjectCELL*);
        static REL::Relocation<GetBhk_t> getBhk{ REL::Offset(0x39b070) };
        outBhkWorld = getBhk(player->parentCell);
        if (!outBhkWorld) return false;
        outHknpWorld = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(outBhkWorld) + 0x60);
        return outHknpWorld != nullptr;
    }

    bool HandCollision::Initialize()
    {
        _leftHandBody.Invalidate();
        _rightHandBody.Invalidate();
        _leftContact.reset();
        _rightContact.reset();
        _bodyCreationBlockedUntil = Utils::GetTime() + 0.75;
        _initialized = true;
        spdlog::info("[HAND_COLLISION] Initialized (ROCK-style, layer 43)");
        return true;
    }

    void HandCollision::Shutdown()
    {
        // Destroy bodies from the physics world before teardown
        auto destroyBody = [](PhysicsHandBody& hb) {
            if (!hb.IsValid() || !hb.hknpWorld) { hb.Invalidate(); return; }
            auto base = REL::Module::get().base();
            __try {
                // Set body to STATIC first — prevents engine from calling computeHardKeyFrame
                // during world teardown. STATIC bodies have no keyframe processing.
                if (hb.collisionObject) {
                    // bhkNPCollisionObject::SetMotionType(0) = STATIC
                    ConstraintFunctions::BhkNPCollisionObjectSetMotionType(hb.collisionObject, 0);
                }
                // Then destroy
                auto destroyBodies = reinterpret_cast<void(__fastcall*)(void*, const std::uint32_t*, int, int)>(base + 0x1544e80);
                std::uint32_t bodyId = hb.bodyId;
                destroyBodies(hb.hknpWorld, &bodyId, 1, 0);
            } __except(EXCEPTION_EXECUTE_HANDLER) {
                // World already torn down
            }
            hb.Invalidate();
        };

        destroyBody(_leftHandBody);
        destroyBody(_rightHandBody);
        DestroyFingerSegments(true);
        DestroyFingerSegments(false);
        ContactImpulseListener::GetSingleton().Unsubscribe();
        _leftContact.reset();
        _rightContact.reset();
        _initialized = false;
        spdlog::info("[HAND_COLLISION] Shutdown");
    }

    // Create a single hand body following ROCK's BethesdaPhysicsBody pattern.
    // halfExtentsGame: box half-extents in game units (x/y/z). The main hand
    // body passes {30,30,30}; finger segments pass the per-segment config size.
    static bool CreateHandBody(PhysicsHandBody& hb, void* hknpWorld, void* bhkWorld,
                               const RE::NiPoint3& pos, bool isLeft,
                               const RE::NiPoint3& halfExtentsGame = RE::NiPoint3(30.0f, 30.0f, 30.0f),
                               const char* debugLabel = nullptr)
    {
        auto base = REL::Module::get().base();
        spdlog::info("[HAND_COLLISION] Creating {} body at ({:.1f},{:.1f},{:.1f}) half=({:.2f},{:.2f},{:.2f})",
                     debugLabel ? debugLabel : (isLeft ? "LEFT" : "RIGHT"),
                     pos.x, pos.y, pos.z,
                     halfExtentsGame.x, halfExtentsGame.y, halfExtentsGame.z);

        // 1. Create shape from caller-supplied half-extents.
        // NOTE: alignas(16) on RE::NiPoint4 locals is not reliably honored by MSVC
        // in this function (stack-frame shape matters — changing args around
        // caused this alignment to break the 16B boundary and crash movaps inside
        // CreateConvexShapeFromHalfExtents). Allocate an aligned buffer instead.
        void* halfExtentsMem = _aligned_malloc(sizeof(RE::NiPoint4), 16);
        if (!halfExtentsMem) return false;
        auto* halfExtentsPtr = new (halfExtentsMem) RE::NiPoint4(
            halfExtentsGame.x * kGameToHavok,
            halfExtentsGame.y * kGameToHavok,
            halfExtentsGame.z * kGameToHavok, 0.0f);
        ConstraintFunctions::hknpConvexShapeBuildConfig buildCfg;
        ConstraintFunctions::BuildConfigCtor(&buildCfg);
        void* shape = ConstraintFunctions::CreateConvexShapeFromHalfExtents(*halfExtentsPtr, 0.05f, &buildCfg);
        _aligned_free(halfExtentsMem);
        if (!shape) { spdlog::error("[HAND_COLLISION] Shape creation failed"); return false; }

        // 2. Body cinfo
        void* cinfoMem = _aligned_malloc(sizeof(hknpBodyCinfo), 16);
        if (!cinfoMem) return false;
        auto* cinfo = reinterpret_cast<hknpBodyCinfo*>(cinfoMem);
        ConstraintFunctions::BodyCinfoCtor(cinfo);
        cinfo->shape = shape;
        cinfo->position = RE::NiPoint4(pos.x * kGameToHavok, pos.y * kGameToHavok, pos.z * kGameToHavok, 0.0f);
        cinfo->orientation = RE::NiPoint4(0, 0, 0, 1);
        cinfo->qualityId = 0;  // STATIC — prevents engine from calling computeHardKeyFrame
        // We handle positioning via direct motion buffer writes, not engine keyframe processing.
        cinfo->materialId = 0;
        // ROCK uses just the layer (&= 0xFFFFFF80; |= layer) — upper bits left zero.
        // Adding a group/subsystem into the upper bits makes F4VR's filter reject
        // pairs we actually want to collide with.
        cinfo->collisionFilterInfo = kHandLayer;

        // 3. Physics system data (material + body cinfo)
        void* sysData = _aligned_malloc(0x90, 16);
        if (!sysData) { _aligned_free(cinfoMem); return false; }
        std::memset(sysData, 0, 0x90);
        ConstraintFunctions::PhysicsSystemDataCtor(sysData);

        // Copy world default material
        void* matMem = _aligned_malloc(0x60, 16);
        if (!matMem) { _aligned_free(cinfoMem); _aligned_free(sysData); return false; }
        std::memset(matMem, 0, 0x60);
        void* matLib = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(hknpWorld) + 0x5c8);
        if (matLib) {
            void* matEntries = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(matLib) + 0x28);
            if (matEntries) std::memcpy(matMem, matEntries, 0x50);
        }

        auto* sd = reinterpret_cast<std::uint8_t*>(sysData);
        *reinterpret_cast<void**>(sd + 0x10) = matMem;
        *reinterpret_cast<std::uint32_t*>(sd + 0x18) = 1;
        *reinterpret_cast<std::uint32_t*>(sd + 0x1C) = 0x80000001;
        *reinterpret_cast<void**>(sd + 0x40) = cinfoMem;
        *reinterpret_cast<std::uint32_t*>(sd + 0x48) = 1;
        *reinterpret_cast<std::uint32_t*>(sd + 0x4C) = 0x80000001;

        // 4. Create Bethesda wrappers
        void* physSys = _aligned_malloc(0x30, 16);
        if (!physSys) { _aligned_free(matMem); _aligned_free(cinfoMem); _aligned_free(sysData); return false; }
        std::memset(physSys, 0, 0x30);
        ConstraintFunctions::BhkPhysicsSystemCtor(physSys, sysData);

        alignas(16) std::uint8_t identityXform[0x40] = {};
        reinterpret_cast<float*>(identityXform)[0] = 1.0f;
        reinterpret_cast<float*>(identityXform)[5] = 1.0f;
        reinterpret_cast<float*>(identityXform)[10] = 1.0f;
        reinterpret_cast<float*>(identityXform)[15] = 1.0f;
        ConstraintFunctions::BhkPhysicsSystemCreateInstance(physSys, bhkWorld, identityXform);

        // 5. AddToWorld (broadphase registration while body is STATIC)
        auto addToWorld = reinterpret_cast<void(__fastcall*)(void*)>(base + 0x1e0c580);
        addToWorld(physSys);

        // 6. Get body ID
        std::uint32_t bodyId = 0x7FFFFFFF;
        ConstraintFunctions::BhkPhysicsSystemGetBodyId(physSys, &bodyId, 0);
        if (bodyId == 0x7FFFFFFF) {
            spdlog::error("[HAND_COLLISION] Failed to get body ID");
            return false;
        }

        // 7. Create collision object wrapper
        void* collObj = _aligned_malloc(0x30, 16);
        if (!collObj) return false;
        std::memset(collObj, 0, 0x30);
        ConstraintFunctions::BhkNPCollisionObjectCtor(collObj, 0, physSys);

        // 8. SetMotionType(KEYFRAMED) via collision object
        ConstraintFunctions::BhkNPCollisionObjectSetMotionType(collObj, 2);

        // 9. Set body+0x88 back-pointer (CRITICAL — 33 engine systems read this)
        void* bodyBuf = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(hknpWorld) + 0x20);
        if (bodyBuf) {
            uintptr_t entry = reinterpret_cast<uintptr_t>(bodyBuf) + (bodyId & 0xFFFF) * 0x90;
            *reinterpret_cast<void**>(entry + 0x88) = collObj;

            // Overwrite materialId to 0 (world default)
            *reinterpret_cast<std::uint16_t*>(entry + 0x70) = 0;
        }

        // 10. Enable body flags: contact modifier + keep-awake (ROCK: 0x08020000)
        auto enableFlags = reinterpret_cast<void(__fastcall*)(void*, std::uint32_t, std::uint32_t, int)>(base + 0x153c090);
        enableFlags(hknpWorld, bodyId, 0x08020000, 0);

        // 11. Activate
        ConstraintFunctions::hknpWorld_commitAddBodies(hknpWorld);
        auto activateBody = reinterpret_cast<void(__fastcall*)(void*, std::uint32_t)>(base + 0x1546ef0);
        activateBody(hknpWorld, bodyId);

        // 12. Register layer
        RegisterHandLayer(hknpWorld);

        // Store results
        hb.bodyId = bodyId;
        hb.shape = shape;
        hb.hknpWorld = hknpWorld;
        hb.bhkWorld = bhkWorld;
        hb.physicsSystem = physSys;
        hb.collisionObject = collObj;
        hb.alignedSystemDataMem = sysData;
        hb.alignedBodyCinfoMem = cinfoMem;
        hb.alignedMaterialMem = matMem;
        hb.valid = true;
        hb.collisionEnabled = true;
        hb.createdTime = Utils::GetTime();

        spdlog::info("[HAND_COLLISION] SUCCESS: {} hand body 0x{:04X}", isLeft ? "LEFT" : "RIGHT", bodyId);
        return true;
    }

    void HandCollision::CreateBodiesIfNeeded(const RE::NiPoint3& leftHandPos, const RE::NiPoint3& rightHandPos)
    {
        if (!g_config.enableHandCollision || !g_config.usePhysicsHandBodies) return;
        if (!_initialized) Initialize();

        void* bhkWorld = nullptr;
        void* hknpWorld = nullptr;
        if (!GetWorlds(bhkWorld, hknpWorld)) return;

        // Check for world change
        if ((_leftHandBody.IsValid() && _leftHandBody.hknpWorld != hknpWorld) ||
            (_rightHandBody.IsValid() && _rightHandBody.hknpWorld != hknpWorld)) {
            _leftHandBody.Invalidate();
            _rightHandBody.Invalidate();
        }

        if (_leftHandBody.IsValid() && _rightHandBody.IsValid()) return;

        if (Utils::GetTime() < _bodyCreationBlockedUntil) return;

        std::scoped_lock lock(_handBodyMutex);
        bool created = false;
        if (!_leftHandBody.IsValid()) {
            if (CreateHandBody(_leftHandBody, hknpWorld, bhkWorld, leftHandPos, true)) created = true;
        }
        if (!_rightHandBody.IsValid()) {
            if (CreateHandBody(_rightHandBody, hknpWorld, bhkWorld, rightHandPos, false)) created = true;
        }

        // Subscribe contact listener after body creation
        if (created) {
            auto& cl = ContactImpulseListener::GetSingleton();
            cl.SetWorld(bhkWorld);
            if (_leftHandBody.IsValid()) cl.SubscribeForBody(_leftHandBody.bodyId, true);
            if (_rightHandBody.IsValid()) cl.SubscribeForBody(_rightHandBody.bodyId, false);

            // Log body state for diagnostics
            void* bodyBuf = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(hknpWorld) + 0x20);
            if (bodyBuf) {
                auto logBody = [&](const PhysicsHandBody& hb, const char* name) {
                    uintptr_t e = reinterpret_cast<uintptr_t>(bodyBuf) + (hb.bodyId & 0xFFFF) * 0x90;
                    std::uint32_t flags = *reinterpret_cast<std::uint32_t*>(e + 0x40);
                    std::uint32_t filter = *reinterpret_cast<std::uint32_t*>(e + 0x44);
                    std::int32_t motId = *reinterpret_cast<std::int32_t*>(e + 0x68);
                    std::int32_t bpH = *reinterpret_cast<std::int32_t*>(e + 0x6c);
                    void* backPtr = *reinterpret_cast<void**>(e + 0x88);
                    spdlog::info("[HAND_COLLISION] {} DIAG: flags=0x{:08X} filter=0x{:08X} motId={} bpH={} backPtr={:p}",
                                 name, flags, filter, motId, bpH, backPtr);
                };
                if (_leftHandBody.IsValid()) logBody(_leftHandBody, "LEFT");
                if (_rightHandBody.IsValid()) logBody(_rightHandBody, "RIGHT");
            }
        }
    }

    void HandCollision::ApplyPlayerPairFilterIfNeeded()
    {
        if (!_initialized || !g_config.enableHandCollision || !g_config.usePhysicsHandBodies) {
            return;
        }

        std::scoped_lock lock(_handBodyMutex);

        if ((!_leftHandBody.IsValid() || _leftHandBody.playerPairFilterApplied) &&
            (!_rightHandBody.IsValid() || _rightHandBody.playerPairFilterApplied)) {
            return;
        }

        std::uint32_t playerBodyId = Physics::GetPlayerBodyId();
        if (playerBodyId == 0x7FFFFFFF || playerBodyId == 0) {
            return;
        }

        void* hknpWorld = GetCurrentHknpWorld();
        if (!hknpWorld) {
            return;
        }

        if (_leftHandBody.IsValid() && !_leftHandBody.playerPairFilterApplied) {
            Physics::DisableCollisionBetween(hknpWorld, _leftHandBody.bodyId, playerBodyId);
            _leftHandBody.playerPairFilterApplied = true;
            spdlog::info("[HAND_COLLISION] Applied player pair filter to LEFT hand body 0x{:08X} vs player 0x{:08X}",
                         _leftHandBody.bodyId, playerBodyId);
        }

        if (_rightHandBody.IsValid() && !_rightHandBody.playerPairFilterApplied) {
            Physics::DisableCollisionBetween(hknpWorld, _rightHandBody.bodyId, playerBodyId);
            _rightHandBody.playerPairFilterApplied = true;
            spdlog::info("[HAND_COLLISION] Applied player pair filter to RIGHT hand body 0x{:08X} vs player 0x{:08X}",
                         _rightHandBody.bodyId, playerBodyId);
        }
    }

    // Move a hand body using ROCK's approach:
    // computeHardKeyFrame → bhkNPCollisionObject::SetTransform + SetVelocity (deferred-safe)
    static void MoveHandBody(PhysicsHandBody& hb, const RE::NiPoint3& pos,
                             const RE::NiMatrix3& rot, float invDeltaTime)
    {
        if (!hb.IsValid() || !hb.hknpWorld || !hb.collisionObject) return;

        // Verify world is still valid
        void* bw = nullptr; void* hw = nullptr;
        if (!GetWorlds(bw, hw) || hw != hb.hknpWorld) return;

        // Skip first few frames after creation to let body settle
        double elapsed = Utils::GetTime() - hb.createdTime;
        if (elapsed < 0.5) return;

        static int moveCount = 0;
        if (++moveCount <= 3 || moveCount % 500 == 0) {
            spdlog::info("[HAND_COLLISION] MoveHandBody #{}: pos=({:.1f},{:.1f},{:.1f}) body=0x{:04X}",
                         moveCount, pos.x, pos.y, pos.z, hb.bodyId);
        }

        auto base = REL::Module::get().base();

        // MSVC does NOT reliably honor alignas(16) on stack locals in this
        // function (observed at runtime: RCX/R15 = ...xxx8, not 16-aligned,
        // causing movaps #GP in computeHardKeyFrame/SetVelocity). Use a
        // static-lifetime aligned scratch block — static storage respects
        // alignas. Single-threaded access (main update thread only).
        struct alignas(16) MoveScratch {
            float hkPos[4];      // offset  0
            float hkOrient[4];   // offset 16
            float linVel[4];     // offset 32
            float angVel[4];     // offset 48
            float lv[4];         // offset 64
            float av[4];         // offset 80
        };
        static MoveScratch s_scratch;

        s_scratch.hkPos[0] = pos.x * kGameToHavok;
        s_scratch.hkPos[1] = pos.y * kGameToHavok;
        s_scratch.hkPos[2] = pos.z * kGameToHavok;
        s_scratch.hkPos[3] = 0.0f;

        // TODO: proper Havok conjugate quaternion conversion - identity for now
        s_scratch.hkOrient[0] = 0.0f;
        s_scratch.hkOrient[1] = 0.0f;
        s_scratch.hkOrient[2] = 0.0f;
        s_scratch.hkOrient[3] = 1.0f;

        auto computeHKF = reinterpret_cast<void(__fastcall*)(void*, std::uint32_t, const float*, const float*, float, float*, float*)>(base + 0x153a6a0);
        auto setXform = reinterpret_cast<void(__fastcall*)(void*, RE::NiTransform*)>(base + 0x1E08A70);
        auto setVel = reinterpret_cast<void(__fastcall*)(void*, const float*, const float*)>(base + 0x1E082A0);
        auto activateBody = reinterpret_cast<void(__fastcall*)(void*, std::uint32_t)>(base + 0x1546ef0);

        // Build NiTransform outside the SEH lambda — __try cannot coexist with
        // C++ objects that require unwinding in the same scope.
        RE::NiTransform xform;
        xform.translate = pos;
        xform.rotate = rot;
        xform.scale = 1.0f;

        // SEH wrap the engine calls: even with IsBodySlotLive probing, the body
        // can be torn down between the probe and these calls (mid-frame cell
        // change, havok world rebuild). On fault, invalidate and let
        // CreateBodiesIfNeeded rebuild next frame.
        auto doEngineCalls = [&]() -> bool {
            __try {
                computeHKF(hb.hknpWorld, hb.bodyId, s_scratch.hkPos, s_scratch.hkOrient,
                           invDeltaTime, s_scratch.linVel, s_scratch.angVel);

                constexpr float maxLinVel = 50.0f;
                for (int i = 0; i < 3; i++) {
                    if (s_scratch.linVel[i] >  maxLinVel) s_scratch.linVel[i] =  maxLinVel;
                    if (s_scratch.linVel[i] < -maxLinVel) s_scratch.linVel[i] = -maxLinVel;
                }

                setXform(hb.collisionObject, &xform);

                s_scratch.lv[0] = s_scratch.linVel[0] * kHavokToGame;
                s_scratch.lv[1] = s_scratch.linVel[1] * kHavokToGame;
                s_scratch.lv[2] = s_scratch.linVel[2] * kHavokToGame;
                s_scratch.lv[3] = 0.0f;
                s_scratch.av[0] = s_scratch.angVel[0];
                s_scratch.av[1] = s_scratch.angVel[1];
                s_scratch.av[2] = s_scratch.angVel[2];
                s_scratch.av[3] = 0.0f;
                setVel(hb.collisionObject, s_scratch.lv, s_scratch.av);

                activateBody(hb.hknpWorld, hb.bodyId);
                return true;
            } __except (EXCEPTION_EXECUTE_HANDLER) {
                return false;
            }
        };

        if (!doEngineCalls()) {
            static int faultCount = 0;
            if (++faultCount <= 5 || faultCount % 500 == 0) {
                spdlog::warn("[HAND_COLLISION] MoveHandBody: SEH fault in engine call for body 0x{:04X} — invalidating (count={})",
                             hb.bodyId, faultCount);
            }
            hb.Invalidate();
        }
    }

    // =====================================================================
    // Task #11: Per-finger-segment KEYFRAMED colliders
    // =====================================================================
    // F4VR distal finger bone names (thumb..pinky). Same skeleton names as
    // FingerCurves.cpp uses; duplicated here to keep HandCollision self-contained.
    static const char* const kDistalFingerBones[2][5] = {
        // Right hand
        { "RArm_Finger13", "RArm_Finger23", "RArm_Finger33", "RArm_Finger43", "RArm_Finger53" },
        // Left hand
        { "LArm_Finger13", "LArm_Finger23", "LArm_Finger33", "LArm_Finger43", "LArm_Finger53" },
    };

    static RE::NiAVObject* GetPlayerSkeletonRoot()
    {
        auto* player = f4vr::getPlayer();
        if (!player || !player->firstPersonSkeleton) return nullptr;
        return player->firstPersonSkeleton;
    }

    void HandCollision::DestroyFingerSegments(bool isLeft)
    {
        auto& segments = isLeft ? _leftFingerSegments : _rightFingerSegments;
        auto base = REL::Module::get().base();
        auto removeFromWorld = reinterpret_cast<void(__fastcall*)(void*)>(base + 0x1e0c820);
        for (auto& hb : segments) {
            if (!hb.IsValid()) continue;
            if (hb.physicsSystem && removeFromWorld) {
                removeFromWorld(hb.physicsSystem);
            }
            if (hb.alignedMaterialMem)     _aligned_free(hb.alignedMaterialMem);
            if (hb.alignedBodyCinfoMem)    _aligned_free(hb.alignedBodyCinfoMem);
            if (hb.alignedSystemDataMem)   _aligned_free(hb.alignedSystemDataMem);
            if (hb.physicsSystem)          _aligned_free(hb.physicsSystem);
            if (hb.collisionObject)        _aligned_free(hb.collisionObject);
            hb.Invalidate();
        }
        _fingerSegmentsReady[isLeft ? 0 : 1] = false;
    }

    void HandCollision::UpdateFingerSegments(bool isLeft, float deltaTime)
    {
        if (!g_config.enableFingerSegmentColliders) {
            if (_fingerSegmentsReady[isLeft ? 0 : 1]) {
                DestroyFingerSegments(isLeft);
            }
            return;
        }

        void* bhkWorld = nullptr;
        void* hknpWorld = nullptr;
        if (!GetWorlds(bhkWorld, hknpWorld)) return;

        // If segments were created in a different world (cell change), tear them
        // down so the next frame recreates them in the current world.
        auto& segments = isLeft ? _leftFingerSegments : _rightFingerSegments;
        bool worldChanged = false;
        for (auto& hb : segments) {
            if (hb.IsValid() && hb.hknpWorld != hknpWorld) { worldChanged = true; break; }
        }
        if (worldChanged) {
            DestroyFingerSegments(isLeft);
        }

        RE::NiAVObject* root = GetPlayerSkeletonRoot();
        if (!root) return;

        const char* const* boneNames = kDistalFingerBones[isLeft ? 1 : 0];

        // Resolve all 5 distal bones this frame. If any are missing, skip
        // creation/update for that finger rather than blocking the whole hand.
        RE::NiAVObject* bones[5] = { nullptr, nullptr, nullptr, nullptr, nullptr };
        int resolved = 0;
        for (int i = 0; i < 5; ++i) {
            bones[i] = f4vr::findAVObject(root, boneNames[i]);
            if (bones[i]) ++resolved;
        }
        if (resolved == 0) return;

        const RE::NiPoint3 halfExt(
            (std::max)(0.05f, g_config.fingerSegmentHalfExtentX),
            (std::max)(0.05f, g_config.fingerSegmentHalfExtentY),
            (std::max)(0.05f, g_config.fingerSegmentHalfExtentZ));
        const float invDt = (deltaTime > 0.0001f) ? (1.0f / deltaTime) : 90.0f;

        for (int i = 0; i < 5; ++i) {
            if (!bones[i]) continue;
            const RE::NiPoint3& pos = bones[i]->world.translate;
            const RE::NiMatrix3& rot = bones[i]->world.rotate;
            PhysicsHandBody& hb = segments[i];

            if (!hb.IsValid()) {
                char label[32];
                std::snprintf(label, sizeof(label), "%s-FINGER%d",
                              isLeft ? "LEFT" : "RIGHT", i);
                if (!CreateHandBody(hb, hknpWorld, bhkWorld, pos, isLeft, halfExt, label)) {
                    continue;
                }
            }
            if (hb.IsValid() && hb.hknpWorld == hknpWorld) {
                MoveHandBody(hb, pos, rot, invDt);
            }
        }

        _fingerSegmentsReady[isLeft ? 0 : 1] = true;
    }

    void HandCollision::Update(const RE::NiPoint3& leftHandPos, const RE::NiPoint3& rightHandPos,
                               const RE::NiPoint3& leftHandVel, const RE::NiPoint3& rightHandVel,
                               const RE::NiMatrix3& leftHandRot, const RE::NiMatrix3& rightHandRot,
                               float deltaTime)
    {
        if (!g_config.enableHandCollision) return;

        _leftHandPos = leftHandPos;
        _rightHandPos = rightHandPos;
        _leftHandVel = leftHandVel;
        _rightHandVel = rightHandVel;

        // Re-register layer 43 (cell changes reset filter matrix)
        void* bhkW = nullptr;
        void* hknpW = nullptr;
        if (GetWorlds(bhkW, hknpW)) {
            RegisterHandLayer(hknpW);
        }

        float invDt = (deltaTime > 0.0001f) ? (1.0f / deltaTime) : 90.0f;

        if (_leftHandBody.IsValid() && _leftHandBody.hknpWorld == hknpW) {
            MoveHandBody(_leftHandBody, leftHandPos, leftHandRot, invDt);
        }
        if (_rightHandBody.IsValid() && _rightHandBody.hknpWorld == hknpW) {
            MoveHandBody(_rightHandBody, rightHandPos, rightHandRot, invDt);
        }

        UpdateFingerSegments(true, deltaTime);
        UpdateFingerSegments(false, deltaTime);

        // Wake sleeping objects near hands
        if (hknpW) {
            auto activateInAabb = reinterpret_cast<void(__fastcall*)(void*, void*)>(REL::Module::get().base() + 0x1546f80);
            float r = 15.0f * kGameToHavok;  // 15 game units wake radius
            for (const auto& p : {leftHandPos, rightHandPos}) {
                float hx = p.x * kGameToHavok, hy = p.y * kGameToHavok, hz = p.z * kGameToHavok;
                alignas(16) float aabb[8] = {hx-r, hy-r, hz-r, 0, hx+r, hy+r, hz+r, 0};
                activateInAabb(hknpW, aabb);
            }
        }
    }

    bool HandCollision::IsInContact(bool isLeft) const
    {
        const auto& c = isLeft ? _leftContact : _rightContact;
        return c.operator bool();
    }

    RE::TESObjectREFR* HandCollision::GetContactObject(bool isLeft) const
    {
        const auto& c = isLeft ? _leftContact : _rightContact;
        if (c) { RE::NiPointer<RE::TESObjectREFR> ptr = c.get(); return ptr.get(); }
        return nullptr;
    }

    const PhysicsHandBody& HandCollision::GetHandBody(bool isLeft) const
    {
        return isLeft ? _leftHandBody : _rightHandBody;
    }

    void HandCollision::TriggerCollisionHaptics(bool isLeft, float intensity, float duration)
    {
        (void)duration;
        int str = static_cast<int>(intensity * 500.0f);
        if (str < 500) str = 500;
        if (str > 50000) str = 50000;
        if (isLeft) _pendingLeftHaptic = str; else _pendingRightHaptic = str;
    }

    void HandCollision::FlushPendingHaptics()
    {
        if (_pendingLeftHaptic > 0) { g_vrInput.TriggerHaptic(true, _pendingLeftHaptic); _pendingLeftHaptic = 0; }
        if (_pendingRightHaptic > 0) { g_vrInput.TriggerHaptic(false, _pendingRightHaptic); _pendingRightHaptic = 0; }
    }

    void* HandCollision::GetCurrentBhkWorld()
    {
        void* bhk = nullptr; void* hknp = nullptr;
        return GetWorlds(bhk, hknp) ? bhk : nullptr;
    }

    void* HandCollision::GetCurrentHknpWorld()
    {
        void* bhk = nullptr; void* hknp = nullptr;
        return GetWorlds(bhk, hknp) ? hknp : nullptr;
    }
}

#include "HIGGS.h"

#include <chrono>

#include "ActivatorHandler.h"
#include "Config.h"
#include "CookingHandler.h"
#include "DropToHand.h"
#include "F4VROffsets.h"
#include "FRIKInterface.h"
#include "Grab.h"
#include "GrabConstraint.h"
#include "Hand.h"
#include "HeisenbergInterface001.h"
#include "Highlight.h"
#include "HandCollision.h"
#include "Hooks.h"
#include "ItemInsertHandler.h"
#include "ItemOffsets.h"
#include "ItemPositionConfigMode.h"
#include "MenuChecker.h"
#include "NodeCaptureMode.h"
#include "OpenVRHook.h"
#include "PipboyInteraction.h"
#include "WaterInteraction.h"
#include "PlayerCharacterProxyListener.h"
#include "SmartGrabHandler.h"
#include "Utils.h"
#include "VRInput.h"

#include "f4vr/F4VRUtils.h"
#include "f4vr/PlayerNodes.h"

namespace heisenberg
{
    // Destructor - defined here where Hand is complete
    Heisenberg::~Heisenberg() = default;

    // F4SE message handler
    static void OnF4SEMessage(F4SE::MessagingInterface::Message* a_msg)
    {
        if (!a_msg) {
            return;
        }

        // Check for API interface request from other plugins
        if (a_msg->type == HeisenbergPluginAPI::HeisenbergMessage::kMessage_GetInterface)
        {
            spdlog::info("[HIGGS] Received API interface request from plugin");
            HeisenbergPluginAPI::HandleInterfaceRequest(
                static_cast<HeisenbergPluginAPI::HeisenbergMessage*>(a_msg->data));
            return;
        }

        switch (a_msg->type) {
        case F4SE::MessagingInterface::kGameLoaded:
            spdlog::info("Game loaded, initializing Heisenberg...");
            g_heisenberg.OnGameLoad();
            break;
        case F4SE::MessagingInterface::kPreLoadGame:
            // v0.5.4 behavior: just log, no loading state
            // Highlighter disabled - no need to clear
            // heisenberg::Highlighter::GetSingleton().ClearAllHighlights();
            // Clear cached menu state on load
            heisenberg::MenuChecker::GetSingleton().ClearState();
            // Clear activator tracking - refs and cell pointer become invalid
            heisenberg::ActivatorHandler::GetSingleton().ClearState();
            // Clear node capture mode
            heisenberg::NodeCaptureMode::GetSingleton().ClearState();
            // Clear hand collision contacts - refs become invalid
            heisenberg::HandCollision::GetSingleton().ClearContacts();
            // Clear pending drops/loots - form IDs become invalid
            heisenberg::DropToHand::GetSingleton().ClearState();
            // Clear cooking handler state - refs become invalid
            heisenberg::CookingHandler::GetSingleton().ClearState();
            // Clear smart grab state - inventory state becomes invalid
            heisenberg::SmartGrabHandler::GetSingleton().ClearState();
            // Unregister proxy listener before player is unloaded
            heisenberg::PlayerCharacterProxyListener::GetSingleton().UnregisterFromPlayer();
            break;
        case F4SE::MessagingInterface::kNewGame:
        case F4SE::MessagingInterface::kPostLoadGame:
            // Reload config so MCM changes take effect without a full game restart
            g_config.Load();
            spdlog::info("Game session started - clearing all grab state");
            heisenberg::GrabManager::GetSingleton().ClearAllState();
            heisenberg::ItemPositionConfigMode::GetSingleton().ClearAllState();
            // Highlighter disabled - no need to clear
            // heisenberg::Highlighter::GetSingleton().ClearAllHighlights();
            // Clear cached menu state
            heisenberg::MenuChecker::GetSingleton().ClearState();
            // Clear activator tracking - refs and cell pointer become invalid
            heisenberg::ActivatorHandler::GetSingleton().ClearState();
            // Clear node capture mode
            heisenberg::NodeCaptureMode::GetSingleton().ClearState();
            // Clear hand collision contacts - refs become invalid
            heisenberg::HandCollision::GetSingleton().ClearContacts();
            // Clear pending drops/loots - form IDs become invalid
            heisenberg::DropToHand::GetSingleton().ClearState();
            // Clear cooking handler state - refs become invalid
            heisenberg::CookingHandler::GetSingleton().ClearState();
            // Clear smart grab state - inventory state becomes invalid
            heisenberg::SmartGrabHandler::GetSingleton().ClearState();
            // Clear hand references to prevent dangling pointers
            g_heisenberg.ClearHandStates();
            break;
        }
    }

    bool Heisenberg::OnF4SEQuery(const F4SE::QueryInterface* a_f4se, F4SE::PluginInfo* a_info)
    {
        // Setup logging using F4SE's logger initialization
        // This uses F4SEPlugin_Version to get the log file name ("Heisenberg_F4VR.log")
        F4SE::log::init();
        
        // Set to WARN for release - config can override via iLogLevel
        spdlog::set_level(spdlog::level::warn);
        spdlog::flush_on(spdlog::level::warn);
        
        // Set cleaner log pattern: [time] [Level] message (no thread ID)
        spdlog::set_pattern("[%T.%e] [%L] %v");
        
        spdlog::info("Heisenberg F4VR v{}.{}.{}", Version::MAJOR, Version::MINOR, Version::PATCH);

        // Fill plugin info
        a_info->infoVersion = F4SE::PluginInfo::kVersion;
        a_info->name = "Heisenberg_F4VR";
        a_info->version = Version::MAJOR;

        // Check runtime
        if (a_f4se->IsEditor()) {
            spdlog::critical("Loaded in editor, aborting");
            return false;
        }

        const auto ver = a_f4se->RuntimeVersion();
        if (ver < F4SE::RUNTIME_VR_1_2_72) {
            spdlog::critical("Unsupported runtime version {}", ver.string());
            return false;
        }

        return true;
    }

    bool Heisenberg::OnF4SELoad(const F4SE::LoadInterface* a_f4se)
    {
        spdlog::info("Heisenberg F4VR loading...");

        F4SE::Init(a_f4se);

        // Get messaging interface
        _messaging = F4SE::GetMessagingInterface();
        if (!_messaging) {
            spdlog::critical("Failed to get messaging interface");
            return false;
        }

        // Register message listener
        if (!_messaging->RegisterListener(OnF4SEMessage)) {
            spdlog::critical("Failed to register message listener");
            return false;
        }

        // Install hooks
        Hooks::Install();

        // Initialize OpenVR hook for controller input interception
        // This must be done before the game calls VR_GetGenericInterface
        auto& openvrHook = OpenVRHook::GetSingleton();
        if (openvrHook.Initialize()) {
            spdlog::info("OpenVR hook initialized - controller input interception enabled");
        } else {
            spdlog::warn("OpenVR hook failed to initialize - input blocking disabled");
        }

        spdlog::info("Heisenberg F4VR loaded successfully");
        return true;
    }

    void Heisenberg::OnGameLoad()
    {
        if (_initialized) {
            spdlog::debug("Heisenberg already initialized");
            return;
        }

        // Load configuration from INI file FIRST (before anything else uses it)
        g_config.Load();
        // Write back immediately so any new keys added in this version
        // are present in the INI for MCM to read on first launch
        spdlog::info(">>> ABOUT TO CALL Config::Save()");
        g_config.Save();
        spdlog::info(">>> Config::Save() RETURNED");
        spdlog::info("Configuration loaded from INI");

        // Create InputEnableLayer for controlling kFighting (like FRIK/VH do)
        auto* inputManager = RE::BSInputEnableManager::GetSingleton();
        if (inputManager && !_inputLayerInitialized) {
            if (inputManager->AllocateNewLayer(_inputLayer, "HeisenbergGrab")) {
                _inputLayerID = _inputLayer->layerID;
                _inputLayerInitialized = true;
                spdlog::info("Created InputEnableLayer 'HeisenbergGrab' with ID {}", _inputLayerID);
            } else {
                spdlog::error("Failed to create InputEnableLayer");
            }
        }

        // Detect Virtual Holsters mod for compatibility mode
        HMODULE vhModule = GetModuleHandleA("VirtualHolsters.dll");
        if (vhModule) {
            _virtualHolstersDetected = true;
            spdlog::info("Virtual Holsters detected - VH compatibility mode active");
        }

        // Initialize FRIK interface for hand tracking
        // Requires FRIK 0.77+ (API version 2)
        auto& frik = FRIKInterface::GetSingleton();
        if (frik.Initialize()) {
            spdlog::info("FRIK interface connected (version: {}) - using FRIK for hand tracking", frik.GetModVersion());
        } else {
            spdlog::warn("FRIK not available or incompatible version - Heisenberg requires FRIK 0.77+");
            spdlog::warn("Heisenberg will use fallback hand tracking (finger poses may not work)");
        }

        // Initialize constraint grab manager for physics-based grabbing
        // (Motor constraints not yet implemented - uses keyframe mode)
        auto& constraintMgr = ConstraintGrabManager::GetSingleton();
        constraintMgr.Initialize();

        // Hand collision system - DISABLED for now, will implement later
        // auto& handCollision = HandCollision::GetSingleton();
        // if (handCollision.Initialize()) {
        //     spdlog::info("Hand collision initialized");
        // }

        // Initialize item offset system for per-item grab positioning
        auto& itemOffsets = ItemOffsetManager::GetSingleton();
        itemOffsets.Initialize();

        // NOTE: We cannot use F4VRCommonFramework's UIManager because it depends on g_mod (ModBase)
        // which Heisenberg doesn't use. A custom NIF-based UI will be needed for item repositioning.

        // Initialize item position config mode
        auto& itemConfigMode = ItemPositionConfigMode::GetSingleton();
        itemConfigMode.Initialize();
        
        // Initialize item insert handler (Port-A-Diner, Nuka machines, etc.)
        auto& itemInsertHandler = ItemInsertHandler::GetSingleton();
        itemInsertHandler.Initialize();
        
        // Initialize cooking handler (heat-based cooking with grabbed items)
        auto& cookingHandler = CookingHandler::GetSingleton();
        cookingHandler.Initialize();
        
        // Initialize smart grab handler (context-aware inventory retrieval)
        auto& smartGrabHandler = SmartGrabHandler::GetSingleton();
        smartGrabHandler.Initialize();

        // Initialize water interaction system (ripples/splashes for VR hands)
        auto& waterInteraction = WaterInteraction::GetSingleton();
        waterInteraction.Initialize();
        
        // Register OpenVR controller state callback to block buttons in certain situations:
        // 1. Block grip when weapon is holstered (prevents native unholster)
        // 2. Block buttons on grabbing hand (prevents Virtual Holsters interference)
        // 3. In grenade zone: Remap A→Grip for grenades, block VH's grip
        auto& openvrHook = OpenVRHook::GetSingleton();
        if (openvrHook.IsHooked()) {
            openvrHook.RegisterControllerStateCallback([](bool isLeft, vr::VRControllerState_t* state) -> uint64_t {
                uint64_t allowMask = 0xFFFFFFFFFFFFFFFF;  // Start with all buttons allowed
                
                // THREAD SAFETY LOGGING: Track callback entry for deadlock diagnosis
                // This helps identify if we got stuck inside the callback
                static std::atomic<int> callbackEntryCount{0};
                static std::atomic<int> callbackExitCount{0};
                int entryNum = ++callbackEntryCount;
                
                // Log every 300th callback to show we're still processing (roughly every 3-5 seconds)
                if (entryNum % 300 == 0) {
                    spdlog::debug("[CB HEARTBEAT] OpenVR callback #{} (exits: {}), hand: {}", 
                                 entryNum, callbackExitCount.load(), isLeft ? "L" : "R");
                }
                
                // =====================================================================
                // EARLY NULL CHECKS - Singletons may not be ready during startup/shutdown
                // =====================================================================
                auto* heisenbergPtr = &Heisenberg::GetSingleton();
                if (!heisenbergPtr || !heisenbergPtr->IsInitialized()) {
                    ++callbackExitCount;
                    return allowMask;  // Not ready yet
                }
                auto& higgs = *heisenbergPtr;
                
                // GrabManager singleton - should always be valid if Heisenberg is initialized
                auto& grabMgr = GrabManager::GetSingleton();
                
                // =====================================================================
                // EITHER HAND: Track physical grip state (for main thread finger logic)
                // =====================================================================
                // Just set the atomic flag - main thread decides finger animation
                {
                    constexpr uint64_t gripMask = 1ULL << vr::k_EButton_Grip;
                    bool physicalGripPressed = (state->ulButtonPressed & gripMask) != 0;
                    
                    if (isLeft) {
                        higgs._physicalGripPressedLeft.store(physicalGripPressed, std::memory_order_relaxed);
                    } else {
                        higgs._physicalGripPressedRight.store(physicalGripPressed, std::memory_order_relaxed);
                    }
                }
                
                // Get state for THIS hand
                bool thisHandGrabbing = isLeft ? grabMgr.GetGrabState(true).active 
                                               : grabMgr.GetGrabState(false).active;
                
                // Determine if this is the primary (weapon) hand
                // Primary = right hand normally, left hand in left-handed mode
                bool isLeftHandedMode = VRInput::GetSingleton().IsLeftHandedMode();
                bool isPrimaryHand = (isLeftHandedMode ? isLeft : !isLeft);
                
                // Check if grenade handling is enabled at all
                // If enableGrenadeHandling=false: mod doesn't touch grenade input at all (game handles natively)
                // If enableGrenadeHandling=true: check remap and zone settings
                // Grenades are handled by the PRIMARY hand (weapon hand)
                bool inGrenadeZone = isPrimaryHand && higgs.IsInChestPocketZone();
                bool grenadeRemapActive = isPrimaryHand && g_config.enableGrenadeHandling && 
                    g_config.remapGrenadeButtonToA && 
                    (g_config.throwableActivationZone == 0 || inGrenadeZone);
                
                // =====================================================================
                // BLOCK A+GRIP FOR VH: When this hand is actively grabbing something
                // =====================================================================
                if (thisHandGrabbing) {
                    constexpr uint64_t aButtonMask = 1ULL << vr::k_EButton_A;
                    constexpr uint64_t gripMask = 1ULL << vr::k_EButton_Grip;
                    allowMask &= ~aButtonMask;  // Block A
                    allowMask &= ~gripMask;     // Block Grip
                }
                
                // =====================================================================
                // BLOCK GRIP DURING STICKY GRAB COOLDOWN (per-hand)
                // =====================================================================
                // After releasing a sticky grab (DropToHand item) or storing an item,
                // there's a 1 second cooldown to prevent accidental re-grab.
                // Only blocks grip on the specific hand that triggered the cooldown.
                if (higgs.IsInStickyGrabCooldown(isLeft)) {
                    constexpr uint64_t gripMask = 1ULL << vr::k_EButton_Grip;
                    bool gripPressed = (state->ulButtonPressed & gripMask) != 0;
                    if (gripPressed) {
                        state->ulButtonPressed &= ~gripMask;  // Strip grip from state
                        
                        // Log periodically
                        int cooldownBlockCounter = higgs._cb_cooldownBlockCounter.load(std::memory_order_relaxed);
                        if (++cooldownBlockCounter % 30 == 1) {
                            spdlog::debug("[COOLDOWN] Blocking grip on {} hand - in cooldown",
                                         isLeft ? "LEFT" : "RIGHT");
                        }
                        higgs._cb_cooldownBlockCounter.store(cooldownBlockCounter, std::memory_order_relaxed);
                    }
                }
                
                // =====================================================================
                // GRENADE REMAP: Hold A for 0.3s → Grip for native grenades
                // =====================================================================
                // When remapGrenadeButtonToA is enabled:
                // - Quick tap A = normal A function (looting, activating)
                // - Hold A for 0.3s = inject Grip (ready grenade)
                // - Physical Grip is blocked from grenades (but HIGGS still sees it via unfiltered input)
                // This allows A to work normally while also supporting grenades
                double aButtonPressTime = higgs._cb_aButtonPressTime.load(std::memory_order_relaxed);
                bool aButtonHeldLongEnough = higgs._cb_aButtonHeldLongEnough.load(std::memory_order_relaxed);
                bool aButtonWasPressed = higgs._cb_aButtonWasPressed.load(std::memory_order_relaxed);
                
                if (grenadeRemapActive && !thisHandGrabbing) {
                    constexpr uint64_t aButtonMask = 1ULL << vr::k_EButton_A;
                    constexpr float holdThresholdSeconds = 0.3f;
                    
                    bool aPressed = (state->ulButtonPressed & aButtonMask) != 0;
                    
                    if (aPressed && !aButtonWasPressed) {
                        // A just pressed - start timing
                        aButtonPressTime = Utils::GetTime();
                        aButtonHeldLongEnough = false;
                    }
                    else if (aPressed && aButtonWasPressed) {
                        // A still held - check duration
                        double now = Utils::GetTime();
                        float heldSeconds = static_cast<float>(now - aButtonPressTime);
                        
                        if (heldSeconds >= holdThresholdSeconds) {
                            aButtonHeldLongEnough = true;
                        }
                    }
                    else if (!aPressed) {
                        // A released - reset state
                        aButtonHeldLongEnough = false;
                    }
                    
                    aButtonWasPressed = aPressed;
                    
                    // NOTE: Grip injection happens below after we strip physical grip
                }
                
                // =====================================================================
                // BLOCK NATIVE GRIP FOR GRENADES when A→Grip remap is active
                // =====================================================================
                // When remapGrenadeButtonToA is enabled, we want ONLY the A button
                // (held 0.3s) to activate grenades. Block the physical Grip button from
                // triggering grenades ALWAYS, regardless of grabbing state.
                // 
                // HIGGS grabbing still works because it uses GetControllerStateUnfiltered
                // which bypasses our filter entirely.
                //
                // IMPORTANT: Don't block grip when in menus! Grip is used to close inventory.
                // IMPORTANT: Allow SHORT grip presses (< 0.3s) for reload functionality!
                
                // Check if in a menu - don't block grip in menus (needed for closing inventory)
                bool inMenu = false;
                auto* ui = RE::UI::GetSingleton();
                if (ui && ui->menuMode) {
                    inMenu = true;
                } else {
                    // Also check MenuChecker for specific menus
                    auto& menuChecker = MenuChecker::GetSingleton();
                    inMenu = menuChecker.IsPipboyOpen() || 
                             menuChecker.IsPaused() ||
                             menuChecker.IsMenuOpen("InventoryMenu") ||
                             menuChecker.IsMenuOpen("ContainerMenu") ||
                             menuChecker.IsMenuOpen("FavoritesMenu") ||
                             menuChecker.IsMenuOpen("WorkshopMenu") ||
                             menuChecker.IsGameStopped();
                }
                
                // Track grip button timing for short press detection (reload functionality)
                // Short presses (< holdThreshold) should pass through for reload
                // Long presses (>= holdThreshold) should be blocked (would trigger grenade/unholster)
                // NOTE: Use separate state for PRIMARY hand only to avoid off-hand interference
                double gripPressTimePrimary = higgs._cb_gripPressTimeRight.load(std::memory_order_relaxed);
                bool gripHeldLongEnoughPrimary = higgs._cb_gripHeldLongEnoughRight.load(std::memory_order_relaxed);
                bool gripWasPressedPrimary = higgs._cb_gripWasPressedRight.load(std::memory_order_relaxed);
                
                constexpr uint64_t gripMask = 1ULL << vr::k_EButton_Grip;
                bool gripPressed = (state->ulButtonPressed & gripMask) != 0;
                bool physicalGripPressed = gripPressed;  // Save BEFORE any modifications for holster blocking
                constexpr float holdThresholdSeconds = 0.3f;  // Same as grenade hold time
                
                // Only track grip timing for PRIMARY hand (grenades are primary-hand only)
                bool gripHeldLongEnough = false;
                if (isPrimaryHand && !inMenu && !thisHandGrabbing) {
                    if (gripPressed && !gripWasPressedPrimary) {
                        // Grip just pressed - start timing
                        gripPressTimePrimary = Utils::GetTime();
                        gripHeldLongEnoughPrimary = false;
                    }
                    else if (gripPressed && gripWasPressedPrimary) {
                        // Grip still held - check duration
                        double now = Utils::GetTime();
                        float heldSeconds = static_cast<float>(now - gripPressTimePrimary);
                        
                        if (heldSeconds >= holdThresholdSeconds) {
                            gripHeldLongEnoughPrimary = true;
                        }
                    }
                    else if (!gripPressed) {
                        // Grip released - reset state
                        gripHeldLongEnoughPrimary = false;
                    }
                    gripWasPressedPrimary = gripPressed;
                    gripHeldLongEnough = gripHeldLongEnoughPrimary;
                }
                
                // Block physical grip for grenades on PRIMARY hand when:
                // - Grenade remap is active (A button should be the only way to throw grenades)
                // - NOT in a menu (grip needed for closing inventory)
                // NOTE: We block grip regardless of grabbing state! HIGGS uses unfiltered input.
                if (grenadeRemapActive && !inMenu) {
                    // STEP 1: Strip long-held physical grip to prevent native grenades
                    // Short grip presses (<0.3s) pass through for reload functionality
                    if (gripHeldLongEnough) {
                        state->ulButtonPressed &= ~gripMask;  // Remove long-held physical grip
                    }
                    
                    // STEP 2: Inject grip when A is held long enough (even if physical grip not pressed)
                    // This allows A button to throw grenades
                    if (aButtonHeldLongEnough) {
                        state->ulButtonPressed |= gripMask;  // Inject grip from A button
                    }
                }
                
                // =====================================================================
                // BLOCK GRIP FOR ANY HAND WITH VALID SELECTION
                // =====================================================================
                // Block grip when:
                // 1. Actively holding an object (thisHandGrabbing), OR
                // 2. Have valid selection (prevents weapon unholster, allows clean grab)
                bool hasSelection = false;
                if (isLeft) {
                    hasSelection = higgs.GetLeftHand() && higgs.GetLeftHand()->GetSelection().IsValid();
                } else {
                    hasSelection = higgs.GetRightHand() && higgs.GetRightHand()->GetSelection().IsValid();
                }
                
                bool shouldBlockGrip = physicalGripPressed && (thisHandGrabbing || hasSelection);
                
                if (shouldBlockGrip) {
                    constexpr uint64_t gripButtonMask = 1ULL << vr::k_EButton_Grip;
                    // Block grip by removing from pressed state
                    state->ulButtonPressed &= ~gripButtonMask;
                    
                    // If A button was held (grenade throw), re-inject grip for PRIMARY hand only
                    // This ensures A→grip still works for grenades while grabbing
                    if (isPrimaryHand && aButtonHeldLongEnough) {
                        state->ulButtonPressed |= gripButtonMask;
                    }
                }
                
                // Debug logging - periodically log blocking state (only at debug level)
                int logCounter = higgs._cb_logCounter.load(std::memory_order_relaxed);
                if (isPrimaryHand && (++logCounter % 600 == 0)) {
                    spdlog::debug("[GRIP] Primary hand: grabbing={} hasSelection={} blocking={}",
                                 thisHandGrabbing, hasSelection, shouldBlockGrip);
                }

                // Write back all modified callback state to atomics
                higgs._cb_aButtonPressTime.store(aButtonPressTime, std::memory_order_relaxed);
                higgs._cb_aButtonHeldLongEnough.store(aButtonHeldLongEnough, std::memory_order_relaxed);
                higgs._cb_aButtonWasPressed.store(aButtonWasPressed, std::memory_order_relaxed);
                higgs._cb_gripPressTimeRight.store(gripPressTimePrimary, std::memory_order_relaxed);
                higgs._cb_gripHeldLongEnoughRight.store(gripHeldLongEnoughPrimary, std::memory_order_relaxed);
                higgs._cb_gripWasPressedRight.store(gripWasPressedPrimary, std::memory_order_relaxed);
                higgs._cb_logCounter.store(logCounter, std::memory_order_relaxed);

                // THREAD SAFETY LOGGING: Track callback exit
                ++callbackExitCount;
                
                return allowMask;
            });
            spdlog::info("Registered button blocking callback (A→Grip remap in grenade zone)");
        }
        
        // Initialize drop-to-hand feature
        auto& dropToHand = DropToHand::GetSingleton();
        dropToHand.Initialize();
        spdlog::info("Drop-to-hand feature initialized");
        
        // Initialize activator handler for touch-based button/switch activation
        if (g_config.enableInteractiveActivators) {
            ActivatorHandler::GetSingleton().Initialize();
            spdlog::info("Interactive activator handler initialized");
            
            // Initialize player character proxy listener to prevent hands from pushing player back
            // This hooks into the character controller's simplex solver to zero pushback velocities
            auto& proxyListener = PlayerCharacterProxyListener::GetSingleton();
            if (proxyListener.Initialize()) {
                spdlog::info("Player proxy listener initialized - will register when player is ready");
                // Try to register now (may fail if player not ready, will retry in Update)
                if (proxyListener.RegisterWithPlayer()) {
                    spdlog::info("Player proxy listener registered with player");
                } else {
                    spdlog::debug("Player proxy listener will register on next update");
                }
            } else {
                spdlog::warn("Player proxy listener failed to initialize - hands may push player");
            }
        }
        
        // Initialize object highlighter
        if (g_config.enableHighlighting) {
            auto& highlighter = Highlighter::GetSingleton();
            if (highlighter.Initialize()) {
                spdlog::info("Object highlighter initialized");
            } else {
                spdlog::warn("Object highlighter failed to initialize - highlighting disabled");
            }
        }
        
        // Initialize event-based menu checker (safer than calling UI::GetMenuOpen from hooks)
        // This caches menu states via MenuOpenCloseEvent to avoid race conditions
        if (MenuChecker::GetSingleton().Initialize()) {
            spdlog::info("Event-based menu checker initialized");
        } else {
            spdlog::warn("Menu checker failed to initialize - using direct UI calls (less safe)");
        }
        
        // Configure native grenade behavior based on settings
        // - If zone enabled (throwableActivationZone=1): disable until hand enters zone
        // - If zone disabled (throwableActivationZone=0) + remap enabled: always enable with 0.3
        // Native throwables are ALWAYS blocked by Heisenberg to prevent accidental throws
        {
            auto* throwDelaySetting = f4cf::f4vr::getIniSetting("fThrowDelay:Controls");
            if (throwDelaySetting) {
                if (g_config.throwableActivationZone == 0 && g_config.remapGrenadeButtonToA) {
                    // Zone disabled + remap enabled = always enable grenades
                    throwDelaySetting->SetFloat(0.3f);
                } else {
                    // Zone enabled = disable until hand enters zone
                    throwDelaySetting->SetFloat(999999.9f);  // Very high = effectively disabled
                }
            }
        }

        InitHands();
        _initialized = true;
        spdlog::info("Heisenberg initialized");
    }

    void Heisenberg::OnFrameUpdate()
    {
        // If mod is disabled (incompatible FRIK), do nothing
        if (_modDisabled) {
            return;
        }
        
        // Legacy single update - calls both phases for backwards compatibility
        OnInputUpdate();
        OnGrabUpdate();
    }

    void Heisenberg::OnInputUpdate()
    {
        // PRE-PHYSICS UPDATE: Runs BEFORE the engine's physics step
        // Good for: input processing, grab detection, starting grabs
        // BAD for: positioning grabbed objects (will be overwritten by physics)
        
        if (_modDisabled || !_initialized) {
            return;
        }

        auto player = RE::PlayerCharacter::GetSingleton();
        if (!player) {
            return;
        }
        
        // MAIN THREAD HEARTBEAT: Log every ~5 seconds to verify main thread is running
        // If deadlock occurs, this will stop appearing while OpenVR callback heartbeat continues
        static int mainThreadHeartbeat = 0;
        if (++mainThreadHeartbeat >= 450) {  // ~5 seconds at 90fps
            mainThreadHeartbeat = 0;
            spdlog::debug("[MAIN THREAD HEARTBEAT] OnInputUpdate running, frame count={}", mainThreadHeartbeat);
        }
        
        // NOTE: kFighting toggle code removed - was causing issues

        // Update sticky grab cooldowns (1 second cooldown after storage/release)
        // Uses approximate delta time based on 90fps VR headset
        constexpr float deltaTime = 1.0f / 90.0f;
        UpdateStickyGrabCooldowns(deltaTime);
        
        // Update menu close cooldown (1 second after closing pipboy, inventory, etc.)
        MenuChecker::GetSingleton().UpdateMenuCloseCooldown(deltaTime);
        
        // Cache weapon state for thread-safe access from OpenVR callback
        UpdateCachedWeaponState();

        // Heartbeat disabled for release - enable debugLogging in config if needed

        // Process input and hand state - but don't update grab positions yet
        // Hand::Update() handles input processing and grab detection
        UpdateHands();
        
        // Update finger close state AFTER hands (needs current selection state)
        UpdateFingerCloseState();
        
        UpdateInputSuppression();
        UpdateChestPocketZone();
        UpdateStorageZoneConfig();
        
        // Update activator handler (checks for cell changes and rescans)
        if (g_config.enableInteractiveActivators) {
            ActivatorHandler::GetSingleton().Update();
            
            // NOTE: Proxy listener registration disabled - charController is always null in VR
            // The hand pushback issue is NOT from physics collision - it's from VR hand reach limits
            // TODO: Find and hook the VR roomscale/hand reach constraint system
#if 0
            // Try to register proxy listener with player if not yet done
            // (player may not be ready at OnGameLoad)
            auto& proxyListener = PlayerCharacterProxyListener::GetSingleton();
            if (!proxyListener.GetPlayerProxy()) {
                proxyListener.RegisterWithPlayer();
            }
#endif
        }
        
        // ==== Node Capture Mode ====
        // Hold left thumbstick to enter capture mode.
        // While in mode, right hand shows pointing pose.
        // Hold thumbstick again to capture finger position relative to nearest activator.
        if (g_config.enableInteractiveActivators) {
            NodeCaptureMode::GetSingleton().Update();
        }
        
        // ==== Force Hands Fully Open ====
        // Always keep hands fully extended EXCEPT:
        // - When actively grabbing an object (use item-specific finger curls)
        // - When left hand grip is held with no target (close fingers)
        // - When pointing at an activator (index finger extended)
        // - When Pipboy is open (let FRIK handle hand pose for Pipboy interaction)
        // - When in Node Capture Mode (right hand forced to pointing pose)
        auto& grabMgr = GrabManager::GetSingleton();
        auto& frik = FRIKInterface::GetSingleton();
        
        // Skip ALL hand pose control when Pipboy is open
        bool pipboyOpen = MenuChecker::GetSingleton().IsPipboyOpen();
        bool nodeCaptureActive = NodeCaptureMode::GetSingleton().IsModeActive();
        
        if (!pipboyOpen) {
            // Check if player has a REAL weapon drawn (not Unarmed) - use scene graph mesh detection
            bool hasRealWeaponDrawn = false;
            auto* f4vrPlayer = f4vr::getPlayer();
            if (f4vrPlayer && f4vrPlayer->actorState.IsWeaponDrawn()) {
                if (f4vrPlayer->firstPersonSkeleton) {
                    RE::NiAVObject* weaponNode = heisenberg::Utils::FindNode(
                        f4vrPlayer->firstPersonSkeleton, "Weapon", 15);
                    if (weaponNode) {
                        RE::NiNode* asNode = weaponNode->IsNode();
                        if (asNode && asNode->children.size() > 0) {
                            hasRealWeaponDrawn = true;  // Real weapon mesh present
                        }
                    }
                }
            }
            
            // Determine which hand is primary (holds weapon)
            // Primary = right hand normally, left hand if bLeftHandedMode
            bool isLeftHandedMode = VRInput::GetSingleton().IsLeftHandedMode();
            bool leftIsPrimary = isLeftHandedMode;
            bool rightIsPrimary = !isLeftHandedMode;
            
            // Left hand: force open unless grabbing, grip-held, or pointing at activator
            // Skip if left hand is primary AND weapon is drawn (let FRIK handle weapon pose)
            bool leftGrabbing = grabMgr.IsGrabbing(true);
            bool leftPointing = _leftHand && _leftHand->IsPointingAtActivator();
            bool skipLeftForWeapon = leftIsPrimary && hasRealWeaponDrawn;
            
            if (!skipLeftForWeapon) {
                if (_leftHandGripHeld) {
                    // Grip held with no target - close all fingers
                    frik.SetHandPoseFingerPositions(true, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
                } else if (!leftGrabbing && !leftPointing) {
                    frik.SetHandPoseFingerPositions(true, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
                }
            }
            // If skipLeftForWeapon == true, we do NOTHING - let FRIK handle the weapon pose
            
            // Right hand: force open unless grabbing, grip-held, pointing, or in node capture mode
            // Skip if right hand is primary AND weapon is drawn (let FRIK handle weapon pose)
            bool rightGrabbing = grabMgr.IsGrabbing(false);
            bool rightPointing = _rightHand && _rightHand->IsPointingAtActivator();
            bool skipRightForWeapon = rightIsPrimary && hasRealWeaponDrawn;
            
            if (!skipRightForWeapon) {
                if (_rightHandGripHeld) {
                    // Grip held with no target - close all fingers
                    frik.SetHandPoseFingerPositions(false, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
                } else if (!rightGrabbing && !rightPointing && !nodeCaptureActive) {
                    // No grab, no pointing, not in node capture mode - force hand open
                    frik.SetHandPoseFingerPositions(false, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
                }
            }
            // If skipRightForWeapon == true, we do NOTHING - let FRIK handle the weapon pose
        }
        
        // ==== Apply Finger Curls During Grab ====
        // Continuously apply finger curls from the grab state
        // This is needed because FRIK may override our one-time call at grab start
        // NOTE: STUF VR mod now handles preventing Unarmed equip on grip - no need to unequip here
        if (grabMgr.IsGrabbing(false)) {  // false = right hand
            const auto& rightGrab = grabMgr.GetGrabState(false);
            if (rightGrab.hasItemOffset && rightGrab.itemOffset.hasFingerCurls) {
                frik.SetHandPoseFingerPositions(false, 
                    rightGrab.itemOffset.thumbCurl, rightGrab.itemOffset.indexCurl,
                    rightGrab.itemOffset.middleCurl, rightGrab.itemOffset.ringCurl, 
                    rightGrab.itemOffset.pinkyCurl);
            } else {
                // No custom finger curls - use default open hand while grabbing
                frik.SetHandPoseFingerPositions(false, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
            }
        }
        
        // Also apply finger curls continuously for left hand grabs
        if (grabMgr.IsGrabbing(true)) {  // true = left hand
            const auto& leftGrab = grabMgr.GetGrabState(true);
            if (leftGrab.hasItemOffset && leftGrab.itemOffset.hasFingerCurls) {
                frik.SetHandPoseFingerPositions(true, 
                    leftGrab.itemOffset.thumbCurl, leftGrab.itemOffset.indexCurl,
                    leftGrab.itemOffset.middleCurl, leftGrab.itemOffset.ringCurl, 
                    leftGrab.itemOffset.pinkyCurl);
            } else {
                // No custom finger curls - use default open hand while grabbing
                frik.SetHandPoseFingerPositions(true, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
            }
        }
        
        // ==== Hand Pose Debug Control ====
        // Only active in reposition mode - used to adjust finger curl for positioning
        // Hold left thumbstick click = smoothly open hands
        // Hold right thumbstick click = smoothly close hands
        auto& configMode = ItemPositionConfigMode::GetSingleton();
        if (configMode.IsRepositionModeActive())
        {
            constexpr float poseSpeed = 2.0f;  // Full open/close in 0.5 seconds
            constexpr float poseDeltaTime = 1.0f / 90.0f;
            
            bool leftThumbPressed = g_vrInput.IsPressed(true, VRButton::ThumbstickPress);
            bool rightThumbPressed = g_vrInput.IsPressed(false, VRButton::ThumbstickPress);
            
            if (leftThumbPressed) {
                // Open hands (towards 1.0)
                _leftHandPoseValue += poseSpeed * poseDeltaTime;
                if (_leftHandPoseValue > 1.0f) _leftHandPoseValue = 1.0f;
                _rightHandPoseValue += poseSpeed * poseDeltaTime;
                if (_rightHandPoseValue > 1.0f) _rightHandPoseValue = 1.0f;
                _handPoseOverrideActive = true;
            }
            
            if (rightThumbPressed) {
                // Close hands (towards 0.0)
                _leftHandPoseValue -= poseSpeed * poseDeltaTime;
                if (_leftHandPoseValue < 0.0f) _leftHandPoseValue = 0.0f;
                _rightHandPoseValue -= poseSpeed * poseDeltaTime;
                if (_rightHandPoseValue < 0.0f) _rightHandPoseValue = 0.0f;
                _handPoseOverrideActive = true;
            }
            
            // Apply finger positions when override is active
            if (_handPoseOverrideActive) {
                frik.SetHandPoseFingerPositions(true, _leftHandPoseValue, _leftHandPoseValue, 
                                                _leftHandPoseValue, _leftHandPoseValue, _leftHandPoseValue);
                frik.SetHandPoseFingerPositions(false, _rightHandPoseValue, _rightHandPoseValue, 
                                                _rightHandPoseValue, _rightHandPoseValue, _rightHandPoseValue);
            }
        }
    }

    void Heisenberg::OnGrabUpdate()
    {
        // POST-PHYSICS UPDATE: Runs AFTER the engine's physics step
        // This is the same timing as FRIK's main update.
        // Good for: positioning grabbed objects (our changes won't be overwritten)
        
        if (_modDisabled || !_initialized) {
            return;
        }

        auto player = RE::PlayerCharacter::GetSingleton();
        if (!player) {
            return;
        }

        // Update grab positions - this runs after physics so our SetTransform/velocity
        // changes won't be overwritten by the physics simulation
        auto& grabMgr = GrabManager::GetSingleton();
        grabMgr.PostPhysicsUpdate();

        // Update item position config mode
        auto& itemConfigMode = ItemPositionConfigMode::GetSingleton();
        constexpr float deltaTime = 1.0f / 90.0f;  // Assume 90fps VR
        itemConfigMode.OnFrameUpdate(deltaTime);
        
        // Update drop-to-hand feature (grabs items dropped from inventory)
        auto& dropToHand = DropToHand::GetSingleton();
        dropToHand.OnFrameUpdate(deltaTime);
        
        // Update cooking handler (heat-based cooking with grabbed items)
        auto& cookingHandler = CookingHandler::GetSingleton();
        cookingHandler.Update(deltaTime);
        
        // Update Pipboy tape deck interaction (eject button, holotape insertion)
        auto& pipboyInteraction = PipboyInteraction::GetSingleton();
        pipboyInteraction.OnFrameUpdate(deltaTime);

        // Update water interaction (ripples/splashes when VR hands touch water)
        auto& waterInteraction = WaterInteraction::GetSingleton();
        if (g_config.enableWaterInteraction) {
            auto& wCfg = waterInteraction.GetConfig();
            wCfg.enabled = g_config.enableWaterInteraction;
            wCfg.splashScale = g_config.waterSplashScale;
            wCfg.wakeEnabled = g_config.enableWakeRipples;
            wCfg.wakeAmt = g_config.wakeRippleAmount;
            wCfg.wakeIntervalMs = g_config.wakeRippleIntervalMs;
            wCfg.enableSplashEffects = g_config.enableWaterSplashEffects;
            waterInteraction.Update(deltaTime);
        }
        
        // Note: SmartGrabHandler doesn't need per-frame Update()
        // It's triggered via TrySmartGrab() on grip press in storage zone
        
        // DISABLED FOR TESTING: Update item insert handler (Port-A-Diner, interactive discovery mode, etc.)
        // ItemInsertHandler::GetSingleton().Update();
    }

    bool Heisenberg::IsHoldingAnything() const
    {
        bool leftHolding = _leftHand && _leftHand->IsHolding();
        bool rightHolding = _rightHand && _rightHand->IsHolding();
        return leftHolding || rightHolding;
    }

    void Heisenberg::UpdateInputSuppression()
    {
        // === PART 1: Chest pocket zone + grip = native throwables ===
        // When PRIMARY hand is in chest pocket zone AND grip is pressed, enable native throwables
        // This is simpler than the old double-tap system
        
        // Primary hand = right normally, left in left-handed mode
        bool isLeftHandedMode = VRInput::GetSingleton().IsLeftHandedMode();
        bool primaryHandIsLeft = isLeftHandedMode;
        bool primaryGripPressed = g_vrInput.IsPressed(primaryHandIsLeft, VRButton::Grip);
        
        // Check if we should enable native throwables:
        // - Primary hand must be in chest pocket zone
        // - Grip must be pressed
        bool shouldEnableThrowables = _isInChestPocketZone && primaryGripPressed;
        
        // Detect state changes
        if (shouldEnableThrowables && !_doubleTapHoldActive) {
            _doubleTapHoldActive = true;
            spdlog::info("[INPUT] Primary grip in chest zone - enabling native throwables");
        }
        else if (!shouldEnableThrowables && _doubleTapHoldActive) {
            _doubleTapHoldActive = false;
            spdlog::info("[INPUT] Left chest zone or released grip - disabling native throwables");
        }
        
        _lastRightGripPressed = primaryGripPressed;
        
        // === PART 2: Suppress kFighting during active grabs ===
        // This prevents punch/attack animations from triggering while holding an object
        auto* inputManager = RE::BSInputEnableManager::GetSingleton();
        
        // Suppress kFighting while holding objects
        bool shouldSuppressFighting = IsHoldingAnything();
        
        if (shouldSuppressFighting && !_postGrabFightingSuppressed) {
            if (inputManager) {
                inputManager->ForceUserEventEnabled(RE::UEFlag::kFighting, false);
                spdlog::debug("Heisenberg: Suppressing kFighting while holding");
            }
            _postGrabFightingSuppressed = true;
        }
        else if (!shouldSuppressFighting && _postGrabFightingSuppressed) {
            if (inputManager) {
                inputManager->ForceUserEventEnabled(RE::UEFlag::kFighting, true);
                spdlog::debug("Heisenberg: Restoring kFighting");
            }
            _postGrabFightingSuppressed = false;
        }
        
        // === PART 2.5: REMOVED ===
        // We only sheathe weapon once on grab start (in HasRealWeaponEquipped).
        // After that, native behavior handles trigger to unholster.
        // No continuous forcing needed.
        
        // === PART 3: Always suppress Z-key (native spring mode) ===
        // kZKey = Z key grab/spring in flat mode, also mapped to A/X in VR
        // We ALWAYS want this disabled since HIGGS handles all grabbing
        // Reuse inputManager from PART 2
        if (inputManager && !_zKeySuppressed) {
            inputManager->ForceOtherEventEnabledVR(RE::OEFlag::kZKey, false);
            _zKeySuppressed = true;
            spdlog::debug("Heisenberg: Suppressed native Z-key spring mode");
        }
        
        // === PART 4: Suppress activation when holding objects ===
        // kActivation = A/X button activate prompt
        bool shouldSuppressActivate = IsHoldingAnything();
        
        if (shouldSuppressActivate && !_inputSuppressed) {
            if (inputManager) {
                inputManager->ForceOtherEventEnabledVR(RE::OEFlag::kActivation, false);
                spdlog::info("Heisenberg: Suppressing native activation while holding");
            }
            _inputSuppressed = true;
        }
        else if (!shouldSuppressActivate && _inputSuppressed) {
            if (inputManager) {
                inputManager->ForceOtherEventEnabledVR(RE::OEFlag::kActivation, true);
                spdlog::info("Heisenberg: Restoring native activation");
            }
            _inputSuppressed = false;
        }
    }

    void Heisenberg::UpdateChestPocketZone()
    {
        // Check hand-to-zone distance to enable/disable native grenades
        // When hand is in the configured zone, we enable the native throwable system by
        // setting fThrowDelay to a low value. Otherwise, it's set very high
        // to prevent native grenades from triggering during normal gameplay.
        
        // If A→Grip remap is active, grenades work everywhere via A button
        // No need for zone-based activation - skip all zone logic
        if (g_config.remapGrenadeButtonToA) {
            _isInChestPocketZone = false;
            _wasInChestPocketZone = false;
            return;
        }
        
        // Zone-based activation (only when remap is disabled)
        // If zone is disabled (0), grenades are never allowed - skip all processing
        // This is a COMPLETE early exit - no zone calculations needed
        if (g_config.throwableActivationZone == 0) {
            // One-time cleanup if we were previously in zone
            if (_wasInChestPocketZone) {
                auto* setting = f4cf::f4vr::getIniSetting("fThrowDelay:Controls");
                if (setting) {
                    setting->SetFloat(999999.9f);
                }
            }
            _isInChestPocketZone = false;
            _wasInChestPocketZone = false;
            _wasInChest = false;
            return;  // Complete early exit - skip remaining function
        }
        
        // Don't allow grenades while holding an object
        if (IsHoldingAnything()) {
            // If we were in zone before, disable grenades now
            if (_wasInChestPocketZone) {
                auto* setting = f4cf::f4vr::getIniSetting("fThrowDelay:Controls");
                if (setting) {
                    setting->SetFloat(999999.9f);
                    spdlog::info("[GRENADE] Holding object - grenades DISABLED");
                }
                _wasInChestPocketZone = false;
            }
            _isInChestPocketZone = false;
            return;
        }
        
        auto* playerNodes = f4cf::f4vr::getPlayerNodes();
        if (!playerNodes || !playerNodes->primaryWandNode || !playerNodes->HmdNode) {
            return;
        }
        
        // Get PRIMARY hand (weapon hand) position
        // In left-handed mode, this is the left hand; in normal mode, this is the right hand
        RE::NiPoint3 handPos = playerNodes->primaryWandNode->world.translate;
        RE::NiPoint3 hmdPos = playerNodes->HmdNode->world.translate;
        RE::NiMatrix3 hmdRot = playerNodes->HmdNode->world.rotate;
        float hmdScale = playerNodes->HmdNode->world.scale;
        
        // Extract yaw-only rotation from HMD (same as storage zone)
        float forwardX = hmdRot.entry[0][1];
        float forwardY = hmdRot.entry[1][1];
        float length = std::sqrt(forwardX * forwardX + forwardY * forwardY);
        if (length < 0.001f) length = 1.0f;
        forwardX /= length;
        forwardY /= length;
        float rightX = forwardY;
        float rightY = -forwardX;
        
        // Build yaw-only rotation matrix
        RE::NiMatrix3 yawRot;
        yawRot.entry[0][0] = rightX;   yawRot.entry[0][1] = forwardX; yawRot.entry[0][2] = 0.0f;
        yawRot.entry[1][0] = rightY;   yawRot.entry[1][1] = forwardY; yawRot.entry[1][2] = 0.0f;
        yawRot.entry[2][0] = 0.0f;     yawRot.entry[2][1] = 0.0f;     yawRot.entry[2][2] = 1.0f;
        
        // Helper to transform a local offset to world space using yaw-only rotation
        auto transformPoint = [&](float offsetX, float offsetY, float offsetZ) -> RE::NiPoint3 {
            RE::NiPoint3 scaled(offsetX * hmdScale, offsetY * hmdScale, offsetZ * hmdScale);
            RE::NiPoint3 rotated;
            rotated.x = yawRot.entry[0][0] * scaled.x + yawRot.entry[1][0] * scaled.y + yawRot.entry[2][0] * scaled.z;
            rotated.y = yawRot.entry[0][1] * scaled.x + yawRot.entry[1][1] * scaled.y + yawRot.entry[2][1] * scaled.z;
            rotated.z = yawRot.entry[0][2] * scaled.x + yawRot.entry[1][2] * scaled.y + yawRot.entry[2][2] * scaled.z;
            return rotated + hmdPos;
        };
        
        // === Calculate single throwable zone position from config ===
        RE::NiPoint3 zonePos = transformPoint(
            g_config.throwableZoneOffsetX,
            g_config.throwableZoneOffsetY,
            g_config.throwableZoneOffsetZ);
        
        // Calculate distance to zone
        float zoneDist = (handPos - zonePos).Length();
        float radius = g_config.throwableZoneRadius;
        
        // Check if we're in the zone
        bool inZone = zoneDist < radius;
        
        // Update zone state
        _isInChestPocketZone = (g_config.throwableActivationZone != 0) && inZone;
        
        // Haptic feedback on zone entry
        if (inZone && !_wasInChest) {
            g_vrInput.TriggerHaptic(false, 40000);
        }
        
        // Update previous state (reusing _wasInChest for backward compat)
        _wasInChest = inZone;
        
        // Only change INI setting when state changes (to avoid spam)
        if (_isInChestPocketZone && !_wasInChestPocketZone) {
            // Entered zone - enable grenades
            auto* setting = f4cf::f4vr::getIniSetting("fThrowDelay:Controls");
            if (setting) {
                setting->SetFloat(0.3f);  // Native default is ~0.3 seconds
                spdlog::debug("[GRENADE] Entered zone - grenades ENABLED (fThrowDelay=0.3)");
            } else {
                spdlog::warn("[GRENADE] Failed to get fThrowDelay:Controls setting!");
            }
        } 
        else if (!_isInChestPocketZone && _wasInChestPocketZone) {
            // Left zone - disable grenades
            auto* setting = f4cf::f4vr::getIniSetting("fThrowDelay:Controls");
            if (setting) {
                setting->SetFloat(999999.9f);  // Very high = effectively disabled
                spdlog::debug("[GRENADE] Left zone - grenades DISABLED (fThrowDelay=999999)");
            }
        }
        
        _wasInChestPocketZone = _isInChestPocketZone;
    }

    void Heisenberg::UpdateStorageZoneConfig()
    {
        // ===== ITEM STORAGE ZONE CONFIGURATION MODE =====
        // Similar to throwable zone config but for item storage zones
        // Hold A button for 1 second to enter config mode
        // Controls: L-Stick up/down = cycle zones, R-Stick up/down = adjust radius, B = save, A = exit
        
        if (!g_config.enableStorageZoneConfigMode) {
            return;
        }
        
        // Update cooldown timer
        if (_storageConfigCooldown > 0.0f) {
            _storageConfigCooldown -= 0.016f;
            if (_storageConfigCooldown < 0.0f) _storageConfigCooldown = 0.0f;
        }
        
        // Helper lambda to enable/disable player controls
        auto setPlayerControlsEnabled = [](bool enabled) {
            auto* player = RE::PlayerCharacter::GetSingleton();
            if (player) {
                f4cf::f4vr::SetActorRestrained(player, !enabled);
            }
            
            auto* inputManager = RE::BSInputEnableManager::GetSingleton();
            if (inputManager) {
                using UEFlag = RE::UserEvents::USER_EVENT_FLAG;
                UEFlag flagsToControl = UEFlag::kMainFour | UEFlag::kVATS | UEFlag::kActivate | UEFlag::kFighting | UEFlag::kMenu;
                inputManager->ForceUserEventEnabled(flagsToControl, enabled);
                
                using OEFlag = RE::OtherInputEvents::OTHER_EVENT_FLAG;
                OEFlag otherFlags = OEFlag::kVATS | OEFlag::kActivation | OEFlag::kFavorites;
                inputManager->ForceOtherEventEnabledVR(otherFlags, enabled);
            }
        };
        
        bool aButtonPressed = g_vrInput.IsPressed(false, VRButton::A);  // A button on right controller
        
        if (_storageConfigModeActive) {
            // Already in config mode - handle input
            setPlayerControlsEnabled(false);
            
            // === TRIGGER TO SET ZONE POSITION IN REAL-TIME ===
            static bool lastTrigger = false;
            bool triggerPressed = g_vrInput.IsPressed(false, VRButton::Trigger);  // Right trigger
            if (triggerPressed && !lastTrigger) {
                auto* playerNodes = f4cf::f4vr::getPlayerNodes();
                if (playerNodes && playerNodes->primaryWandNode && playerNodes->HmdNode) {
                    RE::NiPoint3 handPos = playerNodes->primaryWandNode->world.translate;
                    RE::NiPoint3 hmdPos = playerNodes->HmdNode->world.translate;
                    RE::NiMatrix3 hmdRot = playerNodes->HmdNode->world.rotate;
                    float hmdScale = playerNodes->HmdNode->world.scale;
                    
                    // Extract yaw-only rotation from HMD to make zone body-relative
                    // (not affected by head tilt/pitch)
                    float forwardX = hmdRot.entry[0][1];  // Y column, X row
                    float forwardY = hmdRot.entry[1][1];  // Y column, Y row
                    float length = std::sqrt(forwardX * forwardX + forwardY * forwardY);
                    if (length < 0.001f) length = 1.0f;
                    forwardX /= length;
                    forwardY /= length;
                    float rightX = forwardY;
                    float rightY = -forwardX;
                    
                    // Build yaw-only rotation matrix
                    RE::NiMatrix3 yawRot;
                    yawRot.entry[0][0] = rightX;   yawRot.entry[0][1] = forwardX; yawRot.entry[0][2] = 0.0f;
                    yawRot.entry[1][0] = rightY;   yawRot.entry[1][1] = forwardY; yawRot.entry[1][2] = 0.0f;
                    yawRot.entry[2][0] = 0.0f;     yawRot.entry[2][1] = 0.0f;     yawRot.entry[2][2] = 1.0f;
                    
                    // Calculate local offset using yaw-only rotation (inverse/transpose)
                    RE::NiPoint3 worldOffset = handPos - hmdPos;
                    RE::NiPoint3 localOffset;
                    localOffset.x = yawRot.entry[0][0] * worldOffset.x + yawRot.entry[1][0] * worldOffset.y + yawRot.entry[2][0] * worldOffset.z;
                    localOffset.y = yawRot.entry[0][1] * worldOffset.x + yawRot.entry[1][1] * worldOffset.y + yawRot.entry[2][1] * worldOffset.z;
                    localOffset.z = yawRot.entry[0][2] * worldOffset.x + yawRot.entry[1][2] * worldOffset.y + yawRot.entry[2][2] * worldOffset.z;
                    localOffset.x /= hmdScale;
                    localOffset.y /= hmdScale;
                    localOffset.z /= hmdScale;
                    
                    // Set single storage zone position
                    g_config.storageZoneOffsetX = localOffset.x;
                    g_config.storageZoneOffsetY = localOffset.y;
                    g_config.storageZoneOffsetZ = localOffset.z;
                    
                    spdlog::debug("=== STORAGE ZONE POSITION SET ===");
                    spdlog::debug("NEW POSITION: X={:.2f}, Y={:.2f}, Z={:.2f}", 
                                 localOffset.x, localOffset.y, localOffset.z);
                    
                    char msg[256];
                    snprintf(msg, sizeof(msg), "Storage Zone SET: X=%.1f Y=%.1f Z=%.1f | B=save", 
                             localOffset.x, localOffset.y, localOffset.z);
                    heisenberg::ShowHUDMessage_VR(msg, nullptr, false, false);
                    g_vrInput.TriggerHaptic(false, 30000);
                }
            }
            lastTrigger = triggerPressed;
            
            // A button to exit (without saving)
            static bool lastA = false;
            if (_storageConfigJustEntered) {
                if (!aButtonPressed) {
                    _storageConfigJustEntered = false;
                }
                lastA = aButtonPressed;
            } else if (aButtonPressed && !lastA) {
                setPlayerControlsEnabled(true);
                heisenberg::ShowHUDMessage_VR("Storage Zone Config EXITED", nullptr, false, false);
                g_vrInput.TriggerHaptic(false, 30000);
                _storageConfigModeActive = false;
                _storageConfigCooldown = 2.0f;
                spdlog::info("[STORAGE CONFIG] Exited without saving");
                lastA = aButtonPressed;
                return;
            }
            lastA = aButtonPressed;
            
            // B button to save and exit
            static bool lastB = false;
            bool bPressed = g_vrInput.IsPressed(false, VRButton::B);
            if (bPressed && !lastB) {
                g_config.Save();
                setPlayerControlsEnabled(true);
                heisenberg::ShowHUDMessage_VR("Storage zone SAVED to INI!", nullptr, false, false);
                g_vrInput.TriggerHaptic(false, 50000);
                _storageConfigModeActive = false;
                _storageConfigCooldown = 2.0f;
                spdlog::info("[STORAGE CONFIG] Saved and exited");
                lastB = bPressed;
                return;
            }
            lastB = bPressed;
            
            // Left stick Y to adjust radius
            float leftStickY = g_vrInput.GetThumbstickY(true);  // Left thumbstick
            if (std::abs(leftStickY) > 0.3f) {
                g_config.itemStorageZoneRadius += leftStickY * 0.5f;
                if (g_config.itemStorageZoneRadius < 5.0f) g_config.itemStorageZoneRadius = 5.0f;
                if (g_config.itemStorageZoneRadius > 50.0f) g_config.itemStorageZoneRadius = 50.0f;
                
                static float radiusMsgTimer = 0.0f;
                radiusMsgTimer += 0.016f;
                if (radiusMsgTimer > 0.1f) {
                    radiusMsgTimer = 0.0f;
                    char msg[64];
                    snprintf(msg, sizeof(msg), "Storage Radius: %.0f cm", g_config.itemStorageZoneRadius * 1.4f);
                    heisenberg::ShowHUDMessage_VR(msg, nullptr, false, false);
                }
            }
            
        } else {
            // Not in config mode - check for activation (long press A button)
            static bool lastAEntry = false;
            if (_storageConfigCooldown > 0.0f) {
                lastAEntry = aButtonPressed;
            } else if (aButtonPressed) {
                if (!lastAEntry) {
                    _storageConfigModeHoldTimer = 0.0f;
                }
                _storageConfigModeHoldTimer += 0.016f;
                
                if (_storageConfigModeHoldTimer > 1.0f) {
                    _storageConfigModeActive = true;
                    _storageConfigModeHoldTimer = 0.0f;
                    _storageConfigCooldown = 2.0f;
                    _storageConfigJustEntered = true;
                    
                    // Block controls immediately on entry
                    setPlayerControlsEnabled(false);
                    
                    char msg[128];
                    snprintf(msg, sizeof(msg), "STORAGE ZONE CONFIG | Radius: %.0fcm | Pos: (%.0f, %.0f, %.0f)", 
                             g_config.itemStorageZoneRadius * 1.4f,
                             g_config.storageZoneOffsetX, g_config.storageZoneOffsetY, g_config.storageZoneOffsetZ);
                    heisenberg::ShowHUDMessage_VR(msg, nullptr, false, false);
                    g_vrInput.TriggerHaptic(false, 50000);  // Right hand (where A button is)
                    spdlog::info("[STORAGE CONFIG] Entered storage zone configuration mode");
                    
                    heisenberg::ShowHUDMessage_VR("R-Trigger: set position | L-Stick: radius | B: save | A: exit", nullptr, false, false);
                }
            } else {
                _storageConfigModeHoldTimer = 0.0f;
            }
            lastAEntry = aButtonPressed;
        }
    }

    void Heisenberg::OnGrabStarted(bool isLeft)
    {
        // NOTE: Previously tracked weapon state for Unarmed/holster workarounds.
        // STUF VR mod now handles preventing Unarmed equip on grip, so this is minimal.
        spdlog::debug("[GRAB START] {} hand", isLeft ? "Left" : "Right");
    }

    void Heisenberg::OnGrabEnded(bool isLeft)
    {
        // NOTE: Previously handled Unarmed sheathing and weapon re-holstering.
        // STUF VR mod now handles preventing Unarmed equip on grip, so this is minimal.
        spdlog::debug("[GRAB END] {} hand", isLeft ? "Left" : "Right");
    }

    // =========================================================================
    // STICKY GRAB COOLDOWN - Prevents accidental re-grab after storage/release
    // =========================================================================
    
    void Heisenberg::StartStickyGrabCooldown(bool isLeft)
    {
        constexpr float COOLDOWN_DURATION = 1.0f;  // 1 second cooldown
        
        if (isLeft) {
            _leftStickyGrabCooldown = COOLDOWN_DURATION;
            spdlog::info("[COOLDOWN] Started 1s grip cooldown for LEFT hand");
        } else {
            _rightStickyGrabCooldown = COOLDOWN_DURATION;
            spdlog::info("[COOLDOWN] Started 1s grip cooldown for RIGHT hand");
        }
    }
    
    bool Heisenberg::IsInStickyGrabCooldown(bool isLeft) const
    {
        return isLeft ? (_leftStickyGrabCooldown > 0.0f) : (_rightStickyGrabCooldown > 0.0f);
    }
    
    void Heisenberg::UpdateStickyGrabCooldowns(float deltaTime)
    {
        if (_leftStickyGrabCooldown > 0.0f) {
            _leftStickyGrabCooldown -= deltaTime;
            if (_leftStickyGrabCooldown <= 0.0f) {
                _leftStickyGrabCooldown = 0.0f;
                spdlog::debug("[COOLDOWN] LEFT hand cooldown expired");
            }
        }
        
        if (_rightStickyGrabCooldown > 0.0f) {
            _rightStickyGrabCooldown -= deltaTime;
            if (_rightStickyGrabCooldown <= 0.0f) {
                _rightStickyGrabCooldown = 0.0f;
                spdlog::debug("[COOLDOWN] RIGHT hand cooldown expired");
            }
        }
    }
    
    void Heisenberg::UpdateCachedWeaponState()
    {
        // THREAD SAFETY: This function runs on the main thread and caches weapon state
        // so that the OpenVR callback thread can read it safely without accessing
        // game data structures that might be modified by other threads (e.g., job system)
        
        auto* f4vrPlayer = f4vr::getPlayer();
        if (!f4vrPlayer) {
            _cachedWeaponDrawn.store(false, std::memory_order_relaxed);
            _cachedHasRealWeapon.store(false, std::memory_order_relaxed);
            _cachedHasRealWeaponMesh.store(false, std::memory_order_relaxed);
            return;
        }
        
        // Cache weaponDrawn
        bool weaponDrawn = f4vrPlayer->actorState.IsWeaponDrawn();
        _cachedWeaponDrawn.store(weaponDrawn, std::memory_order_relaxed);
        
        // Cache HasRealWeaponEquipped result
        bool hasRealWeapon = HasRealWeaponEquipped();
        _cachedHasRealWeapon.store(hasRealWeapon, std::memory_order_relaxed);
        
        // Cache scene graph check for weapon mesh
        bool hasRealWeaponMesh = false;
        if (f4vrPlayer->firstPersonSkeleton) {
            RE::NiAVObject* weaponNode = heisenberg::Utils::FindNode(
                f4vrPlayer->firstPersonSkeleton, "Weapon", 15);
            if (weaponNode) {
                RE::NiNode* asNode = weaponNode->IsNode();
                if (asNode && asNode->children.size() > 0) {
                    hasRealWeaponMesh = true;
                }
            }
        }
        _cachedHasRealWeaponMesh.store(hasRealWeaponMesh, std::memory_order_relaxed);
        
        // Periodic logging of cached weapon state (every ~5 seconds at 90fps = 450 frames)
        static int cacheLogCounter = 0;
        if (++cacheLogCounter >= 450) {
            cacheLogCounter = 0;
            spdlog::debug("[WEAPON CACHE] drawn={} realWeapon={} realMesh={}", 
                         weaponDrawn, hasRealWeapon, hasRealWeaponMesh);
        }
    }

    void Heisenberg::UpdateFingerCloseState()
    {
        // =====================================================================
        // FINGER CLOSE LOGIC (runs on main thread)
        // =====================================================================
        // Decide whether to close fingers based on grip state, selection, and weapon state.
        // This replaces the logic that was in the OpenVR callback.
        
        auto& grabMgr = GrabManager::GetSingleton();
        
        // Process each hand
        for (int hand = 0; hand < 2; ++hand) {
            bool isLeft = (hand == 0);
            
            // Read grip state from OpenVR callback (atomic)
            bool physicalGripPressed = isLeft 
                ? _physicalGripPressedLeft.load(std::memory_order_relaxed)
                : _physicalGripPressedRight.load(std::memory_order_relaxed);
            
            // Check selection state (main thread - safe to access Hand directly)
            bool hasSelection = false;
            if (isLeft && _leftHand) {
                hasSelection = _leftHand->GetSelection().IsValid();
            } else if (!isLeft && _rightHand) {
                hasSelection = _rightHand->GetSelection().IsValid();
            }
            
            // Check grab state
            bool isGrabbing = grabMgr.IsGrabbing(isLeft);
            bool otherHandGrabbing = grabMgr.IsGrabbing(!isLeft);
            
            // Check if this is the primary hand (weapon hand)
            // Primary = right hand normally, left hand if bLeftHandedMode
            bool isLeftHandedMode = VRInput::GetSingleton().IsLeftHandedMode();
            bool isPrimaryHand = (isLeftHandedMode ? isLeft : !isLeft);
            
            // For primary hand only: skip finger control if weapon is drawn
            // Let FRIK handle weapon hand finger poses entirely
            bool skipDueToWeapon = false;
            if (isPrimaryHand) {
                bool hasRealWeaponMesh = _cachedHasRealWeaponMesh.load(std::memory_order_relaxed);
                bool weaponDrawn = _cachedWeaponDrawn.load(std::memory_order_relaxed);
                skipDueToWeapon = weaponDrawn && hasRealWeaponMesh;
            }
            
            // Get reference to the appropriate grip-held flag
            bool& gripHeldFlag = isLeft ? _leftHandGripHeld : _rightHandGripHeld;
            bool oldFlag = gripHeldFlag;
            
            // When weapon is drawn on primary hand, DON'T modify gripHeldFlag at all.
            // Let FRIK handle the weapon hand finger pose.
            if (skipDueToWeapon) {
                continue;
            }
            
            // Don't close fist if: has selection, is grabbing, or other hand grabbing
            if (physicalGripPressed && !hasSelection && !isGrabbing && !otherHandGrabbing) {
                gripHeldFlag = true;
            } else {
                gripHeldFlag = false;
            }
            
            // Log state changes
            if (gripHeldFlag != oldFlag) {
                spdlog::debug("[GRIP] {} hand {} fingers", 
                             isLeft ? "Left" : "Right",
                             gripHeldFlag ? "closing" : "opening");
            }
        }
    }

    void Heisenberg::InitHands()
    {
        _leftHand = std::make_unique<Hand>(true);
        _rightHand = std::make_unique<Hand>(false);
    }

    void Heisenberg::UpdateHands()
    {
        if (_leftHand) {
            _leftHand->Update();
        }
        if (_rightHand) {
            _rightHand->Update();
        }
        
        // Hand collision disabled - was causing unwanted object movement
        // The HandCollision system creates physics bodies that can push objects
        // If needed, can be re-enabled via INI: bEnableHandCollision=true
        // if (_leftHand && _rightHand && g_config.enableHandCollision) {
        //     auto& handCollision = HandCollision::GetSingleton();
        //     handCollision.Update(
        //         _leftHand->GetPosition(), _rightHand->GetPosition(),
        //         _leftHand->GetVelocity(), _rightHand->GetVelocity(),
        //         1.0f / 90.0f  // Approximate delta time
        //     );
        // }
    }
}

// ============================================================================
// F4SE PLUGIN VERSION DATA
// ============================================================================
// This struct is required for F4SE::log::init() to properly name the log file.
// It exports a "F4SEPlugin_Version" symbol that CommonLibF4 looks up.

extern "C" DLLEXPORT constinit F4SE::PluginVersionData F4SEPlugin_Version = []() {
    F4SE::PluginVersionData v{};
    v.PluginVersion({ Version::MAJOR, Version::MINOR, Version::PATCH, 0 });
    v.PluginName("HeisenbergF4VR");
    v.AuthorName("FeverDream");
    v.UsesAddressLibrary(true);
    v.IsLayoutDependent(true);
    v.CompatibleVersions({ F4SE::RUNTIME_VR_1_2_72 });
    return v;
}();

// F4SE plugin entry points
extern "C" DLLEXPORT bool F4SEAPI F4SEPlugin_Query(const F4SE::QueryInterface* a_f4se, F4SE::PluginInfo* a_info)
{
    return heisenberg::g_heisenberg.OnF4SEQuery(a_f4se, a_info);
}

extern "C" DLLEXPORT bool F4SEAPI F4SEPlugin_Load(const F4SE::LoadInterface* a_f4se)
{
    return heisenberg::g_heisenberg.OnF4SELoad(a_f4se);
}

// ============================================================================
// HEISENBERG API EXPORTS
// ============================================================================
// These exports allow other mods (like Virtual Holsters) to query our state.
// This enables cross-mod compatibility without modifying the other mods' code.
// They can LoadLibrary("Heisenberg_F4VR.dll") and GetProcAddress to check state.

/**
 * IsHeisenbergGrabbing - Check if HIGGS is currently grabbing an object
 * 
 * Returns true if either hand is actively holding an object.
 * Other mods should check this before triggering their own grab/holster actions.
 * 
 * Usage from other mods:
 *   typedef bool (*IsHeisenbergGrabbing_t)();
 *   HMODULE hMod = GetModuleHandleA("Heisenberg_F4VR.dll");
 *   if (hMod) {
 *       auto func = (IsHeisenbergGrabbing_t)GetProcAddress(hMod, "IsHeisenbergGrabbing");
 *       if (func && func()) { ... HIGGS is grabbing, skip holster action ... }
 *   }
 */
extern "C" DLLEXPORT bool IsHeisenbergGrabbing()
{
    return heisenberg::g_heisenberg.IsHoldingAnything();
}

/**
 * IsHeisenbergGrabbingLeft - Check if the left hand is grabbing
 */
extern "C" DLLEXPORT bool IsHeisenbergGrabbingLeft()
{
    auto& grabMgr = heisenberg::GrabManager::GetSingleton();
    return grabMgr.GetGrabState(true).active;
}

/**
 * IsHeisenbergGrabbingRight - Check if the right hand is grabbing
 */
extern "C" DLLEXPORT bool IsHeisenbergGrabbingRight()
{
    auto& grabMgr = heisenberg::GrabManager::GetSingleton();
    return grabMgr.GetGrabState(false).active;
}


